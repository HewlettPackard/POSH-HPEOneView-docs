The PowerShell script collects information of BladeSystem managed by HP OneView:
�	IP addresses of devices and servers
�	Firmware of various components
�	Serial Number and Part Numbers
�	Servers characteristic
�	Server connections to Interconnect devices
