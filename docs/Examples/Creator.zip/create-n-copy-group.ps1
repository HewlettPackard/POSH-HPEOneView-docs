1..12 | % { 
$i="{0:00}" -f $_ 
$filename = "GRP$i-EthernetNetworks.csv" 
type c:\oneview\csv\group\1-EthernetNetworks.csv | % { $_ -replace "GRPxx-", "GRP$i-" } | out-file $filename
#copy $filename "\\$i\c$\oneview\csv\1-ethernetnetworks.csv" 
}


