﻿## -------------------------------------------------------------------------------------------------------------
##
##
##      Description: Creator functions
##
## DISCLAIMER
## The sample scripts are not supported under any HP standard support program or service.
## The sample scripts are provided AS IS without warranty of any kind. 
## HP further disclaims all implied warranties including, without limitation, any implied 
## warranties of merchantability or of fitness for a particular purpose. 
##
##    
## Scenario
##     	Automate setup of objects in OneView
##		
##
## Input parameters:
##         OVApplianceIP                      = IP address of the OV appliance
##		   OVAdminName                        = Administrator name of the appliance
##         OVAdminPassword                    = Administrator's password
##         OVEthernetNetworksCSV              = path to the CSV file containing Ethernet networks definition
##         OVFCNetworksCSV                    = path to the CSV file containing FC networks definition
##         OVSANManagerCSV                    = path to the CSV file containing SAN Manager definition
##         OVLogicalInterConnectCGroupSV      = path to the CSV file containing Logical Interconnect Group
##         OVUpLinkSetCSV                     = path to the CSV file containing UplinkSet
##         OVEnclosureGroupCSV                = path to the CSV file containing Enclosure Group
##         OVEnclosureCSV                     = path to the CSV file containing Enclosure definition
##         OVProfileConnectionCSV             = path to the CSV file containing Profile Connections definition
##         OVProfileCSV                       = path to the CSV file containing Server Profile definition
##
## History: 
##         August-15-2014: Update for v1.10
##         Sep-20-2014   : Add Storage management 
##         Feb-27-2015   : Update for v1.20
##         March-2015    : Review HPOV profile creation
##                          - Remove Floppy from Boot Order
##                          - Check for existing profile AND server assigned before creating profile
##                          - NEED to WORK on EUFI 
##
##        January-2016   : Minor corrections - Validate that it works against OneView 2.0
##                         - Add SAN Manager
##                         - Add StorageSystem
##                         - Add Storage Volume Template
##
##        January 2016   : -Fix issues with names of Enclosure Group containing spaces in Create-Enclosure function
##                         - Add logic to handle Server Profile NAme
##                         - Add logic to handle unassigned profile
##                         - Add paramater ForceAdd to fore importing the enclosure
##                         - Update StorageSystem before creating storage profiles
##                         - Validate on DCS 2.0
##
##        March 2016 :     - Remove old code with task.uri in Create-Ethernetnetwokrs create FC networks, create Storage volume and templates 
##                         - Add $global: applianceconnection to save the ApplinaceConnection object
##                         - Remove -ligname old parameter and replace it with -Resource in Create-UpLinkset
##                         - Add Appliance connection param in create StorageVolume Template and Create StorageVolume
##
##       April 2016:       - Add  logic to create/configure NetworkSet. 
##                         - Add logic to handle scenario where a network belongs to multiple network sets
##    
##       May 2016:         - Review Create-HPOVProfile function
##                      
##   Version : 2.00
##
##
## -------------------------------------------------------------------------------------------------------------


Param ( [string]$OVApplianceIP="10.254.1.39", 
        [string]$OVAdminName="Administrator", 
        [string]$OVAdminPassword="P@ssword1",
        [string]$OneViewModule = "HPOneView.200",  # "C:\OneView\PowerShell\HPOneView.120.psm1",

        [string]$OVEthernetNetworksCSV ="",                                               #D:\Oneview Scripts\OV-EthernetNetworks.csv",
        [string]$OVFCNetworksCSV ="",                                                     #D:\Oneview Scripts\OV-FCNetworks.csv",
        
        [string]$OVLogicalInterConnectGroupCSV ="",                                       #D:\Oneview Scripts\OV-LogicalInterConnectGroup.csv",
        [string]$OVUpLinkSetCSV ="",                                                      #D:\Oneview Scripts\OV-UpLinkSet.csv",
        [string]$OVEnclosureGroupCSV ="",                                                 #D:\Oneview Scripts\OV-EnclosureGroup.csv",
        [string]$OVEnclosureCSV ="",                                                      #D:\Oneview Scripts\OV-Enclosure.csv",
        
        
        [string]$OVProfileCSV = "" ,                                                      #D:\Oneview Scripts\OV-Profile.csv",
        [string]$OVProfileConnectionCSV = "",                                              #D:\Oneview Scripts\OV-ProfileConnection.csv",
        [string]$OVProfileTemplate = "",
        [string]$OVProfileStorageCSV = "",       

        [string]$OVSanManagerCSV ="",                                                     #D:\Oneview Scripts\OV-FCNetworks.csv",
        [string]$OVStorageSystemCSV ="",  
                                                        
        [string]$OVStorageVolumeTemplateCSV= "",
        [string]$OVStorageVolumeCSV= "",


        [int]$BayStart,
        [int]$BayEnd,

        [string]$sepchar = "|"
)

Function Write-Log ([string]$text, [bool]$time=$true, [string]$ForegroundColor="Green")
{
    $logfolder = "C:\HPCS"
    if(!(test-path "$($logfolder)\Logs")){new-item -path "$($logfolder)" -name Logs -type directory | out-null}
    $logpath = "$($logfolder)\Logs\Install.log"
    $datetime = (get-date).ToString()
    if(!(test-path $logpath)){Out-File -FilePath $logpath -Encoding ASCII -Force -InputObject "Log file created at $datetime"}
	if ($errorCount -ne $error.Count){
        $errorCount = $error.Count - $errorCount        
        0..$($errorCount-1)|%{
			Out-File -FilePath $logpath -Encoding ASCII -Append -InputObject "************ An exception was caught ****************"
            Out-File -FilePath $logpath -Encoding ASCII -Append -InputObject $error[$_]
			Out-File -FilePath $logpath -Encoding ASCII -Append -InputObject "*****************************************************"
            pause;exit
        }
    }
    if($time -eq $true){$output = "$datetime`t$text"}else{$output = "$text"}
    Out-File -FilePath $logpath -Encoding ASCII -Append -InputObject $output
    write-log -ForegroundColor $ForegroundColor -Object $output
}

Function Get-OVTaskError ($Taskresult)
{
        if ($Taskresult.TaskState -eq "Error")
        {
            $ErrorCode     = $Taskresult.TaskErrors.errorCode
            $ErrorMessage  = $Taskresult.TaskErrors.Message
            $TaskStatus    = $Taskresult.TaskStatus

            write-host -foreground Yellow $TaskStatus
            write-host -foreground Yellow "Error Code --> $ErrorCode"
            write-host -foreground Yellow "Error Message --> $ErrorMessage"
        }
}

## -------------------------------------------------------------------------------------------------------------
##
##                     Function AddTo-NetworkSet
##
## -------------------------------------------------------------------------------------------------------------
Function AddTo-NetworkSet {

##
## INternal function to add Networks to NetworkSet
Param   ([string] $ListNetworkSet, [string] $TypicalBandwidth, [string] $MaxBandwidth, [string] $NetworkName )

    $NetworkSetL   = $ListNetworkSet 
    $NSTBandwidthL = $TypicalBandwidth
    $NSMBandwidthL = $MaxBandwidth
    
    #------------------ Add to NetworkSet if defined
    # Need NetworkSetL NSTBandwidthL NSMBandwidthL NetworkName
    #
    if ($NetworkSetL)
    {
        write-host -ForegroundColor Cyan "Checking relationship of network $NetworkName with NetworkSet ..."
        $NetworkSetList = $networkSetL.Split($sepChar)
        if ($NSTBandwidthL)
            {$NSTBandwidthList = $NSTBandwidthL.Split($sepChar)}
        if ($NSMBandwidthL)
            {$NSMBandwidthList = $NSMBandwidthL.Split($sepChar)}
    }
    
    foreach ($NetworkSetName in $NetworkSetList)
    {
        $listofNetworks = @()
        if ($NetworkSetName)
        {
            $ThisNetworkSet = get-HPOVNetworkSet | where Name -eq $NetworkSetName
            if ($ThisNetworkSet)
            {   # Networkset already exist then save the current list of networks
                $ThisNetworkSet.NetworkUris | % { $listofNetworks += get-hpovnetwork | where uri -match $_}
                
            } 
            else # Create NetworkSet first
            {
                write-host -ForegroundColor Cyan "Creating NetworkSet $NetworkSetName first..."
                
                $ndx = [array]::Indexof($NetworkSetList,$NetworkSetName)
                $NSTbwCmd = $NSMbwCmd = ""
                
                if ($NSTBandwidthList)
                {
                    $NSTBandwidth = 1000 * $NSTBandwidthList[$ndx]
                    $NSTbwCmd = "-typicalBandwidth `$NSTBandwidth "
                }
                if ($NSMBandwidthList)
                {
                    $NSMBandwidth = 1000 * $NSMBandwidthList[$ndx]
                    $NSMbwCmd = " -maximumBandwidth `$NSMBandwidth "
                }
                $NSnetCmd = "-networks `$ListofNetworks "
                $NSCmd = "New-HPOVNetworkSet -name `$NetworkSetName $NSTbwCmd $NSMbwCmd $NSnetCmd "
                $ThisNetworkSet = Invoke-Expression $NSCmd 
            } 
            
            $ThisNetwork = Get-hpovnetwork -name $NetworkName
            $ListofNetworks += $ThisNetwork  # Add the newly created one 
            
            write-host -ForegroundColor Cyan "Adding $NetworkName to networkset $NetworkSetName ..."
            Set-HPOVNetworkSet -netset $ThisNetworkSet -networks $ListofNetworks | Wait-HPOVTaskComplete
            
        }
    }
}

## -------------------------------------------------------------------------------------------------------------
##
##                     Function Create-OVEthernetNetworks
##
## -------------------------------------------------------------------------------------------------------------

Function Create-OVEthernetNetworks {

<#
  .SYNOPSIS
    Configure Networking in OneView
  
  .DESCRIPTION
	Configure Networking in Oneview
        
  .EXAMPLE
    Create-OVEthernetNetworks.ps1  -OVEthernetNetworksCSV c:\Ov-Networks.CSV 



  .PARAMETER OVEthernetNetworksCSV
    Name of the CSV file containing network definition
	

  .Notes
    NAME:  Create-OVEthernetNetworks
    LASTEDIT: 01/13/2016
    KEYWORDS: OV Networks
   
  .Link
     Http://www.hp.com
 
 #Requires PS -Version 3.0
 #>
Param ([string]$OVEthernetNetworksCSV ="D:\Oneview Scripts\OV-EthernetNetworks.csv")

    if ( -not (Test-path $OVEthernetNetworksCSV))
    {
        write-host "No file specified or file $OVEthernetNetworksCSV does not exist."
        return
    }
    # Read the CSV Users file
    $tempFile = [IO.Path]::GetTempFileName()
    type $OVEthernetNetworksCSV | where { ($_ -notlike ",,,,,*") -and ( $_ -notlike "#*") -and ($_ -notlike ",,,#*") } > $tempfile   # Skip blank line

    $CurrentNetworkSet = ""
    $ListofNetworks    = @()

    $ListofNets    = import-csv $tempfile | Sort NetworkSet
  
    foreach ($N in $ListofNets)
    {
        $NetworkSetL   = $N.NetworkSet
        $NSTBandwidthL = $N.NSTypicalBandwidth
        $NSMBandwidthL = $N.NSMaximumBandwidth
        #$NSTBandwidth  = 1000 * $N.NSTypicalBandwidth
        #$NSMBandwidth  = 1000 * $N.NSMaximumBandwidth
        $NSNativeNetL   = $N.NSNativeNetwork


        $NetworkName   = $N.NetworkName
        $vLanID        = $N.vLanID
        $Type          = $N.Type
        $PBandwidth    = 1000 * $N.TypicalBandwidth
        $MBandwidth    = 1000 * $N.MaximumBandwidth
        


        if ( [string]::IsNullOrEmpty($N.Purpose))
            { $Purpose = 'General'}
        else
            { $Purpose = $N.Purpose }

        if ($N.SmartLink -like 'Yes') 
            {$SmartLink = $True}
        else
            {$SmartLink = $false}

        if ($N.PrivateLAN -like 'Yes') 
            {$PLAN = $True}
        else
            {$PLAN = $false}        

        $ThisNetwork = Get-HPOVNetwork | where {($_.Name -like $NetworkName) -and ($_.vLanID -like $VLANID) }

        if ($ThisNetwork -eq $NULL)
        {
            # Create network
 
            write-host -foreground Cyan "-------------------------------------------------------------"
            write-host -foreground Cyan "Creating network $NetworkName...."
            write-host -foreground Cyan "-------------------------------------------------------------"

            $Cmds = "New-HPOVNetwork -name `$NetworkName -type `$Type -vlanId `$vLanID -purpose `$purpose -typicalBandwidth `$PBandwidth -maximumBandwidth `$MBandwidth -privateNetwork `$PLAN -smartLink `$SmartLink"
            
            
            $ThisNetwork = Invoke-Expression $Cmds 
                       
        }
        else
        {
            write-host -ForegroundColor Yellow "Network $NetworkName already existed, Skip creating it..."
        }


            AddTo-NetworkSet -ListNetworkSet $NetworkSetL -TypicalBandwidth $NSTBandwidthL -MaxBandwidth $NSMBandwidthL -NetworkName $NetworkName

         

    }


}



## -------------------------------------------------------------------------------------------------------------
##
##                     Function Create-OVFCNetworks
##
## -------------------------------------------------------------------------------------------------------------

Function Create-OVFCNetworks {
<#
  .SYNOPSIS
    Configure FC Networking in OneView
  
  .DESCRIPTION
	Configure FC Networking in Oneview
        
  .EXAMPLE
    Create-OVFCNetworks  -OVFCNetworksCSV c:\Ov-FCNetworks.CSV 


  .PARAMETER OVFCNetworksCSV
    Name of the CSV file containing network definition


  .Notes
    NAME:  Create-OVFCNetworks
    LASTEDIT: 02/05/2014
    KEYWORDS: OV FC Networks
   
  .Link
     Http://www.hp.com
 
 #Requires PS -Version 3.0
 #>
Param ([string]$OVFCNetworksCSV ="D:\Oneview Scripts\OV-FCNetworks.csv")

    if ( -not (Test-path $OVFCNetworksCSV))
    {
        write-host "No file specified or file $OVFCNetworksCSV does not exist."
        return
    }


    # Read the CSV Users file
    $tempFile = [IO.Path]::GetTempFileName()
    type $OVFCNetworksCSV | where { ($_ -notlike ",,,,*") -and ( $_ -notlike "#*") -and ($_ -notlike ",,,#*") } > $tempfile   # Skip blank line

    
    $script:ListofFCNets = import-csv $tempfile

    foreach ($N in $script:ListofFCNets)
    {

        $NetworkName   = $N.NetworkName



        $FabricType    = $N.FabricType
        $Type          = $N.Type
        $PBandwidth    = 1000 * $N.TypicalBandwidth
        $MBandwidth    = 1000 * $N.MaximumBandwidth
        $LRedistribution = $N.LoginRedistribution
        $LinkStability = $N.LinkStabilityTime
        
       

        $NetworkExisted = Get-HPOVNetwork | where Name -like $NetworkName
        if ($NetworkExisted -eq $NULL)
        {
            # Create network
            write-host -foreground Cyan "-------------------------------------------------------------"
            write-host -foreground Cyan "Creating network $NetworkName...."
            write-host -foreground Cyan "-------------------------------------------------------------"

            $Cmds = "New-HPOVNetwork -name `$NetworkName -type $Type -FabricType $FabricType -typicalBandwidth $PBandwidth -maximumBandwidth $MBandwidth "


            if (-not ([string]::IsNullOrEmpty($LRedistribution)))
                { $Cmds += " -AutoLoginRedistribution $LRedistribution " }

            if (-not ([string]::IsNullOrEmpty($LinkStability)))
                { $Cmds += " -LinkStabilityTime $LinkStability " }

            
            Invoke-Expression $Cmds 

 

        }
        else
        {
            write-host -ForegroundColor Yellow "Network $NetworkName already existed, Skip creating it..."
        }


    }

}

## -------------------------------------------------------------------------------------------------------------
##
##                     Function Create-LogicalInterConnectGroup
##
## -------------------------------------------------------------------------------------------------------------

Function Create-OVLogicalInterConnectGroup {
<#
  .SYNOPSIS
    Configure Logical Interconnect Group in OneView
  
  .DESCRIPTION
	Configure Logical Interconnect Group in Oneview
        
  .EXAMPLE
    Create-OVLogicalInterConnectGroup  -OVLogicalInterConnectGroupCSV c:\OV-LogicalInterconnectGroup.CSV 


  .PARAMETER OVLogicalInterConnectGroupCSV
    Name of the CSV file containing network definition
	


  .Notes
    NAME:  Create-OVLogicalInterConnectGroup
    LASTEDIT: 02/05/2014
    KEYWORDS: OV LogicalInterConnectGroup
   
  .Link
     Http://www.hp.com
 
 #Requires PS -Version 3.0
 #>
Param ([string]$OVLogicalInterConnectGroupCSV ="D:\Oneview Scripts\OV-LogicalInterConnectGroup.csv")



    if ( -not (Test-path $OVLogicalInterConnectGroupCSV))
    {
        write-host "No file specified or file $OVLogicalInterConnectGroupCSV does not exist."
        return
    }



    # Read the CSV Users file
    $tempFile = [IO.Path]::GetTempFileName()
    type $OVLogicalInterConnectGroupCSV | where { ($_ -notlike ",,,,*") -and ( $_ -notlike "#*") -and ($_ -notlike ",,,#*") } > $tempfile   # Skip blank line

    
    $ListofLGs = import-csv $tempfile

    foreach ($L in $ListofLGs)
    {
        $LGName      = $L.LIGName

        $Bays        = @{}
        $BayConfigList   = $L.BayConfig.Split(';')
        foreach($Config in $BayconfigList)
        {
            
            $Key,$Value= $Config.Split('=')
            $Key =  [int]($Key) 
 
            if ([string]::IsNullorEmpty($Value))
            { $Value =""}

            $Bays.Add($Key,$Value) 
        }

        # Add Igmp parameters
        #        
        if ($L.IGMPSnooping -like 'Yes') 
        { 
            $IgmpSnooping = $True

            if (-not ( [string]::IsNullOrEmpty($L.IGMPIdletimeOut)))
                { $IGMPIdleTimeoutCmds = " -IgmpIdleTimeOutInterval $($L.IgmpIdleTimeout) " }
            else
                { $IGMPIdleTimeoutCmds = ""}


            $IgmpCmds = "-enableIGMP `$IGMPSnooping "+ $IGMPIdleTimeoutCmds                  
        }
        else
        {   $IgmpCmds = "" }


        # Add FastMacCache parameters
        #
        if ( $L.FastMacCacheFailover -like 'Yes')
        {
            $FastMacCacheFailover = $True
            if (-not([string]::IsNullOrEmpty($L.MacRefreshInterval)))
                { $FastMacCacheIntervalCmds = " -macRefreshInterval $($L.MacReFreshInterval) " }
            else
                { $FastMacCacheIntervalCmds = ""}

            $FastMacCacheCmds = " -enableFastMacCacheFailover `$FastMacCacheFailover "+ $FastMacCacheIntervalCmds

        }

        # Add NetworkLoopProtection parameter
        #
        if ($L.NetworkLoopProtection -like 'Yes')
            { $NetworkLoopProtectionCmds = " -enableNetworkLoopProtection `$True " }
        else
            { $NetworkLoopProtectionCmds = "" }




        $LGExisted =  Get-HPOVLogicalInterConnectGroup | where Name -like $LGName
        if ($LGExisted -eq $NULL)
        {
            # Create Logical InterConnect

            write-host -foreground Cyan "-------------------------------------------------------------"
            write-host -foreground Cyan "Creating Logical InterConnect Group $LGName...."
            write-host -foreground Cyan "-------------------------------------------------------------"

            $Cmds = "New-HPOVLogicalInterConnectGroup -name `$LGName -Bays `$Bays  " + $IgmpCmds + $FastMacCacheCmds + $NetworkLoopProtectionCmds


           
            Invoke-Expression $Cmds | wait-HPOVTaskComplete


        }
        else
        {
            write-host -ForegroundColor Yellow "Logical InterConnect $LGName already existed, Skip creating it..."
        }


    }

}


## -------------------------------------------------------------------------------------------------------------
##
##                     Function Create-OVUpLinkSet
##
## -------------------------------------------------------------------------------------------------------------

Function Create-OVUpLinkSet {
<#
  .SYNOPSIS
    Configure UpLinkSet in OneView
  
  .DESCRIPTION
	Configure UpLinkSetin Oneview
        
  .EXAMPLE
    .\Create-OVUpLinkSet  -OVUpLinkSetCSV c:\OV-UpLinkSet.CSV 


  .PARAMETER OVUpLinkSetCSV
    Name of the CSV file containing UpLink Set definition
	


  .Notes
    NAME:  Create-OVUpLinkSet
    LASTEDIT: 02/05/2014
    KEYWORDS: OV UpLinkSet
   
  .Link
     Http://www.hp.com
 
 #Requires PS -Version 3.0
 #>
Param ([string]$OVUpLinkSetCSV ="D:\Oneview Scripts\OV-UpLinkSet.csv")


        if ( -not (Test-path $OVUpLinkSetCSV))
        {
            write-host "No file specified or file $OVUpLinkSetCSV does not exist."
            return
        }


        # Read the CSV Users file
        $tempFile = [IO.Path]::GetTempFileName()
        type $OVUpLinkSetCSV | where { ($_ -notlike ",,,,*") -and ( $_ -notlike "#*") -and ($_ -notlike ",,,#*") } > $tempfile   # Skip blank line

    
        $ListofUpLinks = import-csv $tempfile

        foreach ($UL in $ListofUpLinks)
        {
            $LGName      = $UL.LIGName

            $UpLinKSetName = $UL.UpLinkSetName
            $UpLinkSetType  = $UL.UpLinkType
         
            $UpLinkSetPorts = $UL.UpLinkPorts.Split(';')
            $UpLinkSetPorts = $UpLinkSetPorts.Trim()     # Remove spaces
            $UpLinkSetNetworks = $UL.Networks.Split(';')
            $UpLinkSetNetworks = $UpLinkSetNetworks.Trim()     # Remove spaces
            $UpLinkSetNativeNetwork = $UL.NativeEthernetNetwork.Trim()
            $UpLinkSetConnectionMode = $UL.ConnectionMode.Trim()


            $LGExisted = $ThisLIG =  Get-HPOVLogicalInterConnectGroup | where Name -like $LGName
            if ($LGExisted -ne $NULL)
            {
      

                if ($UpLinkSetType -like 'Ethernet')
                {
                    if ( -not([string]::IsNullOrEmpty($UpLinkSetNativeNetwork)))
                         { $NativeNetworkCmds = " -usNativeEthNetwork `$UpLinkSetNativeNetwork " }
                    else
                         { $NativeNetworkCmds = "" }
 

                    if ($UpLinkSetPorts -ne $Null)
                         { $UpLinkPortsCmds = " -usUplinkPorts `$UpLinkSetPorts "}
                    else
                         { $UpLinkPortsCmds = ""}     
   

                    if ( -not([string]::IsNullOrEmpty($UpLinkSetConnectionMode)))
                         { $connectionModeCmds = " -usEthMode `$UpLinkSetConnectionMode " }
                    else
                         { $connectionModeCmds = ""}

  
                    $Cmds = "New-HPOVUplinkSet -Resource `$ThisLIG -usName `$UpLinkSetName -usType `$UpLinkSetType -usNetworks `$UpLinkSetNetworks " + $NativeNetworkCmds + $UpLinkPortsCmds + $connectionModeCmds
                }
                else
                {
                    $Cmds = "New-HPOVUplinkSet -Resource `$ThisLIG -usName `$UpLinkSetName -usType `$UpLinkSetType -usNetworks `$UpLinkSetNetworks  -usUplinkPorts `$UpLinkSetPorts "
                
                }

                write-host -foreground Cyan "-------------------------------------------------------------"
                write-host -foreground Cyan "Creating UpLinkSet $UpLinKSetName ...."
                write-host -foreground Cyan "-------------------------------------------------------------"

                
                
               
                Invoke-Expression $Cmds | wait-HPOVTaskComplete



            }
            else
            {
                write-host -ForegroundColor Yellow "Logical InterConnect Group $LGName not existed, Please create it first..."
            }


        }
}


## -------------------------------------------------------------------------------------------------------------
##
##                     Function Create-OVEnclosureGroup
##
## -------------------------------------------------------------------------------------------------------------

Function Create-OVEnclosureGroup {
<#
  .SYNOPSIS
    Configure Enclosure Group in OneView
  
  .DESCRIPTION
	Configure Enclosure Group in Oneview
        
  .EXAMPLE
    .\Create-OVEnclosureGroup  -OVEnclosureGroupCSV c:\OV-EnclosureGroup.CSV 


  .PARAMETER OVEnclosureGroupCSV
    Name of the CSV file containing Enclosure Group definition
	

  .Notes
    NAME:  Create-OVEnclosureGroup
    LASTEDIT: 02/05/2014
    KEYWORDS: OV EnclosureGroup
   
  .Link
     Http://www.hp.com
 
 #Requires PS -Version 3.0
 #>
Param ( [string]$OVEnclosureGroupCSV ="D:\Oneview Scripts\OV-EnclosureGroup.csv")



        if ( -not (Test-path $OVEnclosureGroupCSV))
        {
            write-host "No file specified or file $OVEnclosureGroupCSV does not exist."
            return
        }


        # Read the CSV  file
        $tempFile = [IO.Path]::GetTempFileName()
        type $OVEnclosureGroupCSV | where { ($_ -notlike ",,*") -and ( $_ -notlike "#*") -and ($_ -notlike ",,,#*") } > $tempfile   # Skip blank line

    
        $ListofEnclosureGroup = import-csv $tempfile

        foreach ($EG in $ListofEnclosureGroup)
        {
            $EGName       = $EG.EnclosureGroupName

            $LIGMapping   = $EG.LogicalInterConnectGroupMapping
            $PowerMode    = $EG.PowerRedundantMode
            $ConfScript   = $EG.ConfigurationScript
            $ApplConn     = $EG.ApplianceConnection


            if ( -not ([string]::IsNullOrEmpty($EGName)))
            {

                
                $LIGHash        = @{}
                $LIGList         = $LIGMapping.Split(';')
                foreach($Config in $LIGList)
                {          
                    $Key,$LIGName= $Config.Split('=')
                    $Key =  [int]($Key) 
                    
                    # Check LIG existence
                   
                    if ( -not ([string]::IsNullOrEmpty($LIGName)))
                    {
                        $ThisLIG = Get-HPOVLogicalInterConnectGroup | where Name -like $LIGName
                        if ($ThisLIG)
                        {
                            $LIGHash.Add($Key,$ThisLIG.uri)
                        }
                        else
                        {
                            write-host -ForegroundColor Yellow "Logical InterConnect Group $LIGName does not exist. Skip including it...." 
                        }
                    
                    }
                    
                    else
                    {
                        write-host -ForegroundColor Yellow "Logical InterConnect Group $LIGName is not specified. Skip including it...." 
                    }
                    

                     
                }

               $LIGMappingParam = " -LogicalInterconnectGroupMapping `$LIGHash  "                

                if (-not ([string]::IsNullOrEmpty($PowerMode)))
                {
                    $PowerModeParam = " -PowerRedundantMode `$PowerMode "

                }

                if (-not ([string]::IsNullOrEmpty($ConfigScript)))
                {
                    $ConfigScriptParam = " -ConfigurationScript `$ConfigScript "

                }
                
                
                $ApplConnParam = " -ApplianceConnection `$global:ApplianceConnection "

            
                $Cmds = "New-HPOVEnclosureGroup -name `$EGName $LiGMappingParam $PowerModeParam  $ConfigScriptParam $ApplConnParam"

                    $EncGroupExisted =  Get-HPOVEnclosureGroup | where name -match $EGName 

                    if (-not $EncGroupExisted )
                    {
                        # Create Enclosure Group

                        write-host -foreground Cyan "-------------------------------------------------------------"
                        write-host -foreground Cyan "Creating Enclosure Group $EGName ...."
                        write-host -foreground Cyan "-------------------------------------------------------------"
            
                       $ThisEG = Invoke-Expression $Cmds 

                        # There is no task uri to check for error
                    }
                    else
                    {
                        write-host -ForegroundColor Yellow "EnclosureGroup $EGName already existed, Skip creating it..."
                    }


                }

            else
            {
                    write-host -ForegroundColor Yellow "Enclosure Group Name is empty.Please provide a name..."
            }  
              

        }
}

## -------------------------------------------------------------------------------------------------------------
##
##                     Function Create-OVEnclosure
##
## -------------------------------------------------------------------------------------------------------------

Function Create-OVEnclosure {
<#
  .SYNOPSIS
    Import Enclosure in OneView
  
  .DESCRIPTION
	Import Enclosure in Oneview
        
  .EXAMPLE
    .\Create-OVEnclosure  -OVEnclosureCSV c:\OV-Enclosure.CSV  


  .PARAMETER OVEnclosureCSV
    Name of the CSV file containing Enclosure  definition
	


  .Notes
    NAME:  Create-OVEnclosure
    LASTEDIT: 02/05/2014
    KEYWORDS: OV Enclosure
   
  .Link
     Http://www.hp.com
 
 #Requires PS -Version 3.0
 #>
Param ( [string]$OVEnclosureCSV ="D:\Oneview Scripts\OV-Enclosure.csv")


        if ( -not (Test-path $OVEnclosureCSV))
        {
            write-host "No file specified or file $OVEnclosureCSV does not exist."
            return
        }


        # Read the CSV  file
        $tempFile = [IO.Path]::GetTempFileName()
        type $OVEnclosureCSV | where { ($_ -notlike ",,,*") -and ( $_ -notlike "#*") -and ($_ -notlike ",,,#*") } > $tempfile   # Skip blank line

    
        $ListofEnclosure = import-csv $tempfile

        foreach ($Encl in $ListofEnclosure)
        {
            $OAIP              = $Encl.OAIPAddress
            $OAADminName       = $Encl.OAADminName 
            $OAADminPassword   = $Encl.OAADminPassword

            $EnclGroupName    = $Encl.EnclosureGroupName
            $Licensing        = $Encl.LicensingIntent
            $FWBaseline       = $Encl.FWBaseline

            $ForceAddCmd      = if (!($Encl.ForceAdd) -or ($Encl.ForceAdd -ieq 'Yes')){ " -Confirm:`$true "} else {" -Confirm:`$false "}

            ## TBD - to validate Licensing intent

            if ( -not ( [string]::IsNullOrEmpty($OAIP) -or [string]::IsNullOrEmpty($OAAdminName) -or [string]::IsNullOrEmpty($OAAdminPassword)`
                       -or [string]::IsNullOrEmpty($EnclGroupName) -or [string]::IsNullOrEmpty($Licensing)))

                         
            {
                ## TBD _ Validate whether we can ping OA?

                $FWCmds = ""
                if ( -not ([string]::IsNullOrEmpty($FWBaseLine)))
                {
                    $FWCmds = " -fwBaselineIsoFilename `$FWBaseLine  "
                }
                $EnclGroupName = "`'$EnclGroupName`'"
                $Cmds = "New-HPOVEnclosure -applianceConnection `$global:ApplianceConnection -oa $OAIP -username $OAAdminName -password $OAAdminPassword -enclGroupName $EnclGroupName -license $Licensing $FWCmds $ForceAddCmd "
 
                $EncExisted =  Get-HPOVEnclosure | where {($_.activeOaPreferredIP -eq $OAIP ) -or ($_.standbyOaPreferredIP -eq $OAIP )}
            

                if ($EncExisted -eq $NULL)
                {

                    write-host -foreground Cyan "-------------------------------------------------------------"
                    write-host -foreground Cyan "Importing Enclosure $OAIP ...."
                    write-host -foreground Cyan "-------------------------------------------------------------"
            
                    
                  Invoke-Expression $Cmds | wait-HPOVTaskComplete

                }
                else
                {
                    write-host -ForegroundColor Yellow "Enclosure $OAIP already existed, Skip creating it..."
                }



            }
            
            else
            {
                    write-host -ForegroundColor Yellow "The following information is not correct `n `
                        Value: OAIP --> $OAIP --- OA Name is empty or OA credentials not provided `n `
                        or Value: Enclosure Group --> $EnclGroupName  ---  Enclosure Group Name is empty `n`
                        or Value: License --> $Licensing --- Licensing Intent is not specified as OneView or OneViewNoiLO `n `
                        Please provide correct information and re-run the script again."
            }   
        }

}


## -------------------------------------------------------------------------------------------------------------
##
##                     Function Create-OVProfileConnection
##
## -------------------------------------------------------------------------------------------------------------

Function Create-OVProfileConnection {
<#
  .SYNOPSIS
    Create ProfileConnection in OneView
  
  .DESCRIPTION
	Create ProfileConnection in OneView and return a hash table of Server ProfileName and connection list
        
  .EXAMPLE
    .\Create-OVProfileConnection  -OVProfileConnectionCSV c:\OV-ProfileConnection.CSV 
    


  .PARAMETER OVProfileConnectionCSV
    Name of the CSV file containing Server Profile Connection definition
	


  .Notes
    NAME:  Create-OVProfileConnection
    LASTEDIT: 05/20/2014
    KEYWORDS: OV Profile Connection
   
  .Link
     Http://www.hp.com
 
 #Requires PS -Version 3.0
 #>
 Param ( [string]$OVProfileConnectionCSV ="D:\Oneview Scripts\OV-ProfileConnection.csv", [string]$OVProfileName="ProfileTemplate1")

         if ( -not (Test-path $OVProfileConnectionCSV))
        {
            write-host "No file specified or file $OVProfileConnectionCSV does not exist."
            return
        }


        # Read the CSV  file
        $tempFile = [IO.Path]::GetTempFileName()
        type $OVProfileConnectionCSV | where { ($_ -notlike ",,,,*") -and ( $_ -notlike "#*") -and ($_ -notlike ",,,#*") } > $tempfile   # Skip blank line

        $ConnectionList = @()     # List of Connections to be associated with a given server profile


        $ListofConnections  = import-csv $tempfile

        foreach ($Conn in $ListofConnections)
        {
            $ServerProfileName  = $Conn.ServerProfileName
            if ($ServerProfileName -eq $OVProfileName)
            {
                $ConnID             = $Conn.ConnectionID
                $ConnType           = $Conn.ConnectionType
                $NetworkName        = $Conn.NetworkName
                $PortID             = $Conn.PortID
                $RequestedBandWidth = $Conn.RequestedBandWidth
                $ConnMacAddress     = $Conn.ConnectionMACAddress
                $ConnWWNN           = $Conn.ConnectionWWNN
                $ConnWWPN           = $Conn.ConnectionWWPN
                $LunID              = $Conn.LunID
                $BootPriority       = $Conn.BootPriority
                $WWPNList           = $Conn.ArrayWWPN

                if ( -not ([string]::IsNullOrEmpty($ConnType) -or [string]::IsNullOrEmpty($NetworkName)))
                {

                   # Configure network
                   $objNetwork = Get-HPOVNetwork | where name -eq $NetworkName
                   if ($objNetwork -eq $NULL)
                   {
                        # Try network set
                        $objNetwork = Get-HPOVNetworkSet | where name -eq $NetworkName
                   }
                   if ($objNetwork -ne $NULL)
                   {
                       # Configure PortID parameter

                       $PortIDCmds = "" 
                       if ( -not [string]::IsNullOrEmpty($PortID))
                            { $PortIDCmds = " -portID `$PortID "}  

                       # Configure RequestBandWidth parameter
                       $RequestBWCmds = "" 
                       if ( -not [string]::IsNullOrEmpty($RequestedBandWidth))
                            { $RequestBWCmds = " -requestedBW $RequestedBandWidth "}  

                       # Configure USerDefined parameters
                       if ( -not ([string]::IsNullOrEmpty($ConnMacAddress) -and [string]::IsNullOrEmpty($ConnWWN) -and [string]::IsNullOrEmpty($ConnWWPN) ))
                       {
                            $MacCmds = $WWNNCmds = $WWPNCmds = "" 

                            if ( -not [string]::IsNullOrEmpty($ConnMacAddress))
                                { $MacCmds = " -mac $ConnMacAddress "} 

                            if ( -not [string]::IsNullOrEmpty($ConnWWN))
                                { $WWNNCmds = " -wwnn $ConnWWN "}

                            if ( -not [string]::IsNullOrEmpty($ConnWWPN))
                                { $WWPNCmds = " -wwpn $ConnWWPN "}

                            $UserDefinedCmds = " -userDefined $MacCmds $WWNNCmds $WWPNCmds "
                       }

                       # Configure Boot Priority parameter
                       $BootPriorityCmds = "" 
                       if ( -not ( [string]::IsNullOrEmpty($BootPriority)) )
                       { 
                            $BootPriorityCmds = " -bootable -priority $BootPriority "
                            if ($ConnType -match 'FibreChannel')
                            {
                                if ( -not( [string]::IsNullOrEmpty($WWpnList) -or [string]::IsNullOrEmpty($LunID)))
                                {
                                    $ArrWWPN = $WWpnList.Split(';')
                                    $BootPriorityCmds += " -arraywwpn `$ArrWWPN -Lun $LunID "
                                }
                            }
                       }

                       $Cmds  = "New-HPOVProfileConnection -connectionID $ConnID -connectionType $ConnType -network `$objNetwork   "
                       $Cmds +=  $PortIDCmds + $RequestBWCmds + $UserDefinedCmds + $BootPriorityCmds 
                  
                       $Connection = Invoke-Expression $Cmds 
                       $ConnectionList += $Connection
                    }
                    else
                    {
                        write-host -ForegroundColor YELLOW "Cannot find network name or network set $NetworkName for this connection. Skip creating Network Connection..."
                    }

                  

                
                }
                else
                {
                    write-host -foreground YELLOW "The following information is not provided: `n `
                                - Connection Type ( Ethernet or Fibre Channel) `n `
                                - Network Name to connect to `n `
                                Please provide information and re-run the command. "                   
                }

            
            }



        }
        
 

        return $ConnectionList

 }




## -------------------------------------------------------------------------------------------------------------
##
##                     Function Create-OVProfile
##
## -------------------------------------------------------------------------------------------------------------

Function Create-OVProfile {
<#
  .SYNOPSIS
    Create Server Profile  in OneView
  
  .DESCRIPTION
	Create Server Profile in OneView
        
  .EXAMPLE
    .\Create-OVProfile -OVProfileConnectionCSV c:\OV-ProfileConnection.CSV -OVProfile c:\OV-Profile.csv
    


  .PARAMETER OVProfileConnectionCSV
    Name of the CSV file that contains definitions of Connections (Ethernet or Fibre Channel) associated to server profiles

  .PARAMETER OVProfileCSV
    Name of the CSV file that contains definitions of server profiles
	


  .Notes
    NAME:  Create-OVProfile
    LASTEDIT: 05/21/2014
    KEYWORDS: OV Profile
   
  .Link
     Http://www.hp.com
 
 #Requires PS -Version 3.0
 #>
 Param ( [string]$OVProfileConnectionCSV  ,
         [string]$OVProfileCSV            , 
         [string]$OVProfileStorageCSV     )           

        if ( -not (Test-path $OVProfileCSV))
        {
            write-host "No file specified or file $OVProfileCSV does not exist."
            return
        }



        # Read the CSV  file
        $tempFile = [IO.Path]::GetTempFileName()
        type $OVProfileCSV | where { ($_ -notlike ",,,,*") -and ( $_ -notlike "#*") -and ($_ -notlike ",,,#*") } > $tempfile   # Skip blank line

        $ListofProfile  = import-csv $tempfile

        foreach ($SP in $ListofProfile)
        {
            $ProfileName     = $SP.ServerProfileName
            $ServerName      = $SP.ServerHardware
            $AssignmentType  = $SP.AssignmentType
            $Description     = $SP.Description

            $EnclGroup       = $SP.EnclosureGroup
            $EnclName        = $SP.EnclosureName
            $SHType          = $SP.ServerHardwareType

            $BayStart        = $SP.BayStart
            $BayEnd          = $SP.BayEnd

            $FWBaseline      = $SP.FWBaseLine
            $FWInstall       = $SP.FWInstall

            $BIOSSettings    = $SP.BIOSSettings
            $bo              = $SP.BootOrder
            $Bootmode        = $SP.BootMode
   

            $MACAssignment   = $SP.MACAssignment
            $WWNAssignment   = $SP.WWNAssignment
            $SNAssignment    = $SP.SNAssignment

            
            
            $script:srvHWType = $SHType


                # Build Assignment Type parameter
                $AssignmentTypeCmds = " -AssignmentType `$AssignmentType  "
                
                
                # Build FWBaseline parameter
                $FWBaselineCmds = ""
                if (-not [string]::IsNullOrEmpty($FWBaseline))
                    { 
                        $FWBaselineCmds = " -firmware -baseline `$FWBaseline "
                        if (-not [string]::IsNullOrEmpty($FWInstall))
                        {
                            $FWBaseLineCmds += " -forceInstallFirmware "
                        }

                    }

                # Build Boot settings 
                if (-not [string]::IsNullOrEmpty($BootMode))
                    { $BootMode = "BIOS"}

                if (-not [string]::IsNullOrEmpty($Bo))
                    { $BootOrderArray = $Bo.Split(';') }





                
                
                # Build Description parameter
                if (-not [string]::IsNullOrEmpty($Description))
                    { $DescCmds = " -description `$Description " }

                
                # Build Connections parameter
                $ConnectionsCmds = "" 

                $ProfilesNConnections = @()
                if ( -not [string]::IsNullOrEmpty($OVProfileConnectionCSV) -and (Test-path $OVProfileConnectionCSV))    # Connections list provided
                {
                    $ProfilesNConnections = Create-OVProfileConnection -OVProfileConnectionCSV $OVProfileConnectionCSV -OVProfileName $ProfileName
                    if ($ProfilesNConnections -ne $NULL)
                    {
                        $ConnectionsCmds = " -Connections `$ProfilesNConnections " 
                    }
                    else
                    {
                        write-host -ForegroundColor Yellow "Cannot find Profile Connections for this profile $ProfileName. Will create profile without ProfileConnections"
                        $ConnectionsCmds = ""
                    }

                }
             

                else
                {
                    write-host -ForegroundColor Yellow "Connections list is empty. Profile will be created without any network/FC connection."
                }

                # Build Storage parameter
                $StsProfileCmds = "" 

                $script:StorageVolList = @()
         
                if ( ! [string]::IsNullOrEmpty($OVProfileStorageCSV) -and (Test-path $OVProfileStorageCSV) )
                {       
                    $stsProfileCmds =Create-OVProfileStorage -OVProfileStorageCSV $OVProfileStorageCSV -OVProfileName $ProfileName
                }
                else
                {
                    write-host -ForegroundColor Yellow "Storage Connections list is empty. Profile will be created without any Storage connection."
                }

                 # Build BIOSSettings parameter
                $BIOSSettingsCmds = ""
                if (-not [string]::IsNullOrEmpty($BIOSSettings))
                    { $BIOSSettingsCmds = " -bios -biosSettings `$BIOSSettings " } 
 
                # Build BootOrder parameter
                $BootOrderCmds = ""
                if ($BootOrderArray -ne $NULL )
                    { $BootOrderCmds = " -ManageBoot -bootOrder `$BootOrderArray " }      

                # Build BootMode parameter
                $BootModeCmds = ""
                $BootModeCmds = " -bootmode $BootMode "  
                
                # Build MACAssignment parameter
                $MACAssignmentCmds = ""
                if (-not [string]::IsNullOrEmpty($MACAssignment))
                    { $MACAssignmentCmds = " -macassignment `$MACAssignment " }                                       

                # Build WWNAssignment parameter
                $WWNAssignmentCmds = ""
                if (-not [string]::IsNullOrEmpty($WWNAssignment))
                    { $WWNAssignmentCmds = " -wwnassignment `$WWNAssignment " }
                
                # Build SNAssignment parameter
                $SNAssignmentCmds = ""
                if (-not [string]::IsNullOrEmpty($SNAssignment))
                    { $SNAssignmentCmds = " -snassignment `$SNAssignment " }  
                  
                # Build EnclosureGroup parameter
                if (-not [string]::IsNullOrEmpty($enclGroup))
                {
                    $ThisEnclosureGroup = Get-HPOVEnclosureGroup | where name -match $EnclGroup
                    $egUri              = $ThisEnclosureGroup.Uri
                    $egCmds             = " -EnclosureGroup `$ThisEnclosureGroup  " 
                }
                
                # Create command to build profile
                $AddressCmds         = " $MACAssignmentCmds $WWNAssignmentCmds  $SNAssignmentCmds "
                $BootCmds            = " $BootOrderCmds $BootModeCmds  "
            
                $GeneralProfileCmds   = "New-HPOVProfile "
                $GeneralProfileCmds  += "  $AssignmentTypeCmds $DescCmds $egCmds "
                
                $GeneralProfileCmds  += " $ConnectionsCmds  $BIOSSettingsCmds $stsProfileCmds "
                $GeneralProfileCmds  += " $BootCmds $AddressCmds "
                
                
                ## ------------------------------------------------
                ## Build profile for a rack
                ##
                if (  $BayStart -and $BayEnd ) 
                {
                    write-host -foreground Cyan "-------------------------------------------------------------"
                    write-host -foreground Cyan "Creating server profiles for enclosure --> $EnclName "
                    write-host -foreground Cyan "-------------------------------------------------------------"
                         
                    foreach ($index in $BayStart..$BayEnd)
                    {
                        $script:ServerCmds = $script:SHTCmds = "" 

                        if ($EnclName)     # Enclosure Name not empty
                        {
                            # if BayStart=BayEnd , we create an unique profile for this bay
                            # Set profile Name to Bayxx for each bay (default Value)
                            if ($BayStart -ne $BayEnd)
                            {
                                $ProfileName = "$EnclName-Bay$Index"
                            }

                            else
                            {
                                if ( !$Profilename)
                                {
                                    $ProfileName = "$EnclName-Bay$Index"
                                    write-host -foreground YelloW "Creating a unique profile but name was not specified. Use default value $ProfileName"
                                }

                            }
                            
                            # Build Server Name
                            $ServerName           = "$EnclName, bay $Index"
                            $ThisServer           = Get-HPOVServer | where name -eq $ServerName

                            if ($ThisServer)          
                            {
                                $SHTUri            = $ThisServer.ServerHardwareTypeUri
                                $ThisSHT           = Get-HPOVServerHardwareType | where uri -eq $SHTUri
                                $SrvUri            = $ThisServer.uri
                                $SrvProfileUri     = $ThisServer.serverProfileUri
                            }  
                            else
                            {
                                ### Hmmm - This should not happen as we are creating profiles for server in an enclosure !!!! - Re-check
                                $ThisSHT           = Get-HPOVServerHardwareType | where name -eq $SHType
                            }                             
                            if ($SrvProfileUri -eq $NULL)
                            {
                              
                                # Check Profile existence
                                $ThisProfile = get-HPOVprofile | where Name -match $ProfileName
                                 
                                if ( $ThisProfile)
                                { # Profile existed}
                               
                                    if ($ThisProfile.serverHardwareuri)
                                    {
                                    write-host -foreground green " Server $Servername already has profile assigned to. Skip creating new profile... " 
                                    $ProfileAction = $False
                                    }
                                    else
                                    {
                                        # Profile existed but not attached to a server
                                        write-host -foreground Green " TBD - Assign this profile to this server"
                                        $ProfileAction = $True
                                    }
                                    
                                }
                                else
                                {
                                    $ProfileAction = $true
                                }
                                if ($ProfileAction)
                                {
                                    write-host -foreground Green "Creating profile $ProfileName now...."
                                    
                                    # Check Firmware management

                                    $ThisModel      = $ThisServer.Model
                                    $OldModel       = ($ThisModel -like '*G7*') -or ($ThisModel -like '*G6*')
                                    $FWBaselineCmds = if ($OldModel) { ""}

                                    
                                    $ServerCmds = "  -server `$ThisServer "                                                
                                    $SHTCmds    = " -sht `$ThisSHT "                                       
                                    
                                    $Cmds = $GeneralProfileCmds + " -name `"$Profilename`" " + " $ServerCmds  $SHTCmds  $FWBaselineCmds" 
                                    
                                    Invoke-Expression $Cmds | Wait-HPOVTaskComplete
                                
                                }
                            }
                            else # Server alrearedy has profile
                            {
                                write-host -foreground Yellow " Server $servername already has profile. Skip creating it...." 
                            }

                        }
                        else
                        {
                            write-host -ForegroundColor Yellow "Enclosure name empty.Can't create profile"
                            break
                        }
                    }

                }
                else
                {
                        # -------------------------------------
                        # No profile builds per rack - Single profile create here

                        $script:ServerCmds = $script:SHTCmds = "" 


                        write-host -foreground Cyan "-------------------------------------------------------------"
                        write-host -foreground Cyan "Creating profile for server --> $ServerName                      "
                        write-host -foreground Cyan "-------------------------------------------------------------"
                        
                        if ([string]::IsNullOrEmpty($Servername))
                        {
                            write-host -ForegroundColor Yellow "Create single profile but server name is not specified. Skip Creation operation"
                        }
                        else 
                        {
                            
                            if ([string]::IsNullOrEmpty($profileName))
                            {
                                $profileName = "Profile for $ServerName"   # No profile name provided - Define default one
                            }
                            
                            $ThisServer           = Get-HPOVServer | where name -eq $ServerName

                            if ($ThisServer)          
                            {
                                $SHTUri            = $ThisServer.ServerHardwareTypeUri
                                $ThisSHT           = Get-HPOVServerHardwareType | where uri -eq $SHTUri
                                $SrvUri            = $ThisServer.uri
                                $SrvProfileUri     = $ThisServer.serverProfileUri
                            }  
                            else
                            {
                                #Should be Unassigned
                                $ThisSHT           = Get-HPOVServerHardwareType | where name -eq $SHType
                            }  # End ThisServer Null                           
                            if ($SrvProfileUri -eq $NULL)
                            {
                                
                                # Check Profile existence
                                $ThisProfile = get-HPOVprofile | where Name -match $ProfileName
                                if ( $ThisProfile)
                                { # Profile existed}
                                    if ($ThisProfile.serverHardwareuri)
                                    {
                                    write-host -foreground green " Server $Servername already has profile assigned to. Skip creating new profile... " 
                                    $ProfileAction = $False
                                    }
                                    else
                                    {
                                        # Profile existed but not attached to a server
                                        if ($ThisServer)
                                        {
                                            write-host -foreground Green " TBD - Assign this profile to this server"
                                            $ProfileAction = $True
                                        }
                                        Else
                                        {
                                            write-host -foreground Yellow " Server Profile already exists. Skip duplicating it... " 
                                            $ProfileAction = $False
                                        }
                                    }
                                    
                                }
                                else
                                {
                                    $ProfileAction = $true
                                }
                                if ($ProfileAction)
                                {
                                    write-host -foreground Green "Creating profile $ProfileName now...."
   
                                    if ($ThisServer)
                                    {
                                        $ServerCmds = "  -server `$ThisServer "     
                                        
                                        # Check Firmware management
                                        $ThisModel      = $ThisServer.Model
                                        $OldModel       = ($ThisModel -like '*G7*') -or ($ThisModel -like '*G6*')
                                        $FWBaselineCmds = if ($OldModel) { ""}
                                    }
                                    else
                                    {
                                        $ServerCmds = ""  # Unassigned profile
                                    }
                                                                                
                                    $SHTCmds    = " -sht `$ThisSHT "                                       
                                    
                                    $Cmds = $GeneralProfileCmds + " -name `"$Profilename`" " + " $ServerCmds  $SHTCmds  $FWBaselineCmds" 
                                    
                                    Invoke-Expression $Cmds | Wait-HPOVTaskComplete
                                
                                }
                            } # End $SrvProfile URI NuLL
                     
                        } # End servername defined
                        
                            

                } #PRofile built per server
            

        }
        

}

## -------------------------------------------------------------------------------------------------------------
##
##                     Function Copy-OVProfile
##
## -------------------------------------------------------------------------------------------------------------

Function Copy-OVProfile {
<#
  .SYNOPSIS
    Copy Server Profile  in OneView
  
  .DESCRIPTION
	Copy Server Profile in OneView
        
  .EXAMPLE
    .\Copy-OVProfile -OVProfileTemplate Template1 -OVEnclosure Rack2Top -BayStart 1 -BayEnd 16
    

  .PARAMETER OVProfileTemplate
    Name of an existing Profile template

  .PARAMETER OVEnclosure
    Name of a registered enclosure

  .PARAMETER BayStart
    Bay number to start with

  .PARAMETER BayEnd
    Bay number to end with


  .Notes
    NAME:  Copy-OVProfile
    LASTEDIT: 05/21/2014
    KEYWORDS: OV Profile
   
  .Link
     Http://www.hp.com
 
 #Requires PS -Version 3.0
 #>
 Param ( [string]$OVProfileTemplate ="",
         [string]$OVEnclosure       ="",
         [int]$BayStart,
         [int]$BayEnd)           


    if ( ($BayStart -ne $NULL) -and ($BayEnd -ne $Null) -and ($OVProfileTemplate) -and ($OVEnclosure) )
    {
        foreach ($index in $BayStart..$BayEnd)
        {
            $s = "$OVEnclosure, Bay $Index"
            #Get-HPOVServer $s
            $task = Copy-HPOVProfile $OVProfileTemplate "Bay$Index" -assign $s
                             
            if ($task)
            {
                $result = Wait-HPOVTaskComplete $task.uri

                Get-OVTaskError -Taskresult $result
            }

            Get-OVTaskError -Taskresult $result
        }

    }
    Else
    {
        write-host "Specify all parameters BayStart, BayEnd,OVProfileTemplate,OVEnclosure and re-run the script "
        return
    }

}

## -------------------------------------------------------------------------------------------------------------
##
##                     Function Create-OVStorageSystem
##
## -------------------------------------------------------------------------------------------------------------

Function Create-OVStorageSystem {
<#
  .SYNOPSIS
    Import a storage system
  
  .DESCRIPTION
	Add storgae system to OneView
        
  .EXAMPLE
    .\Creator.ps1  -OVStorageSystemCSV c:\OV-StorageSystem.CSV 


  .PARAMETER OVStorageSystemCSV
    Name of the CSV file containing Storage System definition
	

  .Notes
    NAME:  Create-OVStorageSystem
    LASTEDIT: 01/17/2016
    KEYWORDS: OV StorageSystem
   
  .Link
     Http://www.hpe.com
 
 #Requires PS -Version 3.0
 #>

Param ( [string]$OVStorageSystemCSV, [string]$OVFCNetworksCSV)

        if ( ! [string]::IsNullOrEmpty($OVFCNetworksCSV) -and (Test-path $OVFCNetworksCSV) )
            {
              
                Create-OVFCNetworks -OVFCNetworksCSV $OVFCNetworksCSV 
            
                ## Update FC networks associated to StorageSystemPorts
                ##
                foreach ($N in $script:ListofFCNets)
                {
                    $FCNet        = $N.NetworkName
                    $FCSwitchName = $N.FCSwitchName
                    if ($FCSwitchName)
                    {
                        $ManagedSAN = Get-HPOVManagedSan -Name $FCSwitchName
                        if ($ManagedSAN)
                        {
                            $SANUri  = $ManagedSAN.uri
                            $ThisNet = Get-HPOVNetwork -name $FCNet
                            if ($ThisNet.ManagedSanURI -ne $SANUri)
                            {
                                write-host -foreground Cyan "-------------------------------------------------------------"
                                write-host -foreground Cyan "Affiliating the FC Network $FCNet with the SAN $FCSwitchName "
                                write-host -foreground Cyan "-------------------------------------------------------------"
                            
                                $UpdateNetwork = Get-HPOVNetwork -name $FCNet | Set-HPOVNetwork -managedSan $ManagedSAN | Wait-HPOVTaskComplete
                            }
                            else
                            {
                                write-host -ForegroundColor Yellow " FC network $FCNet already managed by SAN $FCSwitchName. Skip updating FC network..." 
                            }


                        }

                    }

                }  #end foreach FC Network
                
            }
        else
            {
                write-host -ForegroundColor Yellow "No file specified for FC Network or file $OVFCNetworksCSV does not exist."
                write-host -ForegroundColor Yellow " Skip creating FC networks....." 
            }
        
        if (!( $OVStorageSystemCSV -and (Test-path $OVStorageSystemCSV)))
        {
            write-host "No file specified or file $OVStorageSystemCSV does not exist."
            return
        }



        # Read the CSV  file
        $tempFile = [IO.Path]::GetTempFileName()
        type $OVStorageSystemCSV | where { ($_ -notlike ",,,,*") -and ( $_ -notlike "#*") -and ($_ -notlike ",,,#*") } > $tempfile   # Skip blank line

        $ListofStorageSystem  = import-csv $tempfile

        foreach ($StS in $ListofStorageSystem)
        {
            $StorageHostName         = $StS.StorageHostName
            $StorageAdminname        = $StS.StorageAdminName
            $StorageAdminPassword    = $StS.StorageAdminPassword
            $StorageDomainName       = $StS.StorageDomainName
            $StoragePorts            = $Sts.StoragePorts
            $PortsArray              = $Sts.StoragePorts.Split(";")
            $PoolsArray              = $StS.StoragePools.Split(";")

            
            if ( -not ( [string]::IsNullOrEmpty($StorageHostName) -or [string]::IsNullOrEmpty($StorageAdminName) ) )
            {
                
                $StorageSystemLists = Get-HPOVStorageSystem  
                foreach ($StorageSystem in $StorageSystemLists)
                {
                    $sHostName = $StorageSystem.Credentials.ip_hostName
                    if ($sHostName -ieq $StorageHostName)
                          { break}
                    else  {$sHostName = "" }
                }

                if ($sHostName)
                {
                    write-host -foreground Yellow "Storage System $StorageHostName already exists. Skip adding storage system."
                }
                Else
                {
                    # Add param for StorageSystemPorts
                    if ( -not [string]::IsNullOrEmpty($StorageDomainName))
                    {
                        $DomainParam = " -domain $StorageDomainName" 

                    }
                    else
                    {
                        $DomainParam = " -domain NoDomain "
                    }

                    # Add param for StorageSystemPorts
                    $StorageSystemPorts = @{}
                    foreach ($p in $PortsArray)
                    {
                        $a= $p.Split("=")
                        $Port = $a[0]
                        $Netw = $a[1] 
                        $StorageSystemPorts.Add($port,$netw)
                    }

                    if ($StorageSystemPorts)
                    {
                        $PortsParam = " -ports `$StorageSystemPorts"
                    }
                    else
                    {
                        $PortsParam = "" 
                    }


           
                    $Cmds= "Add-HPOVStorageSystem -hostname $StorageHostName -username $StorageAdminName -password $StorageAdminPassword $DomainParam $PortsParam"

                    write-host -foreground Cyan "-------------------------------------------------------------"
                    write-host -foreground Cyan "Adding storage system $StorageHostName                       "
                    write-host -foreground Cyan "-------------------------------------------------------------"                                

                        
                    Invoke-Expression $Cmds | Wait-HPOVTaskComplete
              
                    #Wait for the storage system to be fully discovered in OneView
                    start-sleep -seconds 60
                    
                    if ($PoolsArray)
                    {
                        ##
                        ## Add StoragePools
                        ##
                        $ThisStorageSystem = Get-HPOVStorageSystem | where {$_.credentials.ip_hostname -eq $StorageHostName}
                        $UnManagedPools    = $NULL

                        if ($ThisStorageSystem)
                        {
                            $UnManagedPools = $ThisStorageSystem.UnManagedPools
                        }

                        foreach ($PoolName in $PoolsArray)
                        {
                            if ( $UnManagedPools -match $PoolName)
                            {
                                write-host -foreground Cyan "-------------------------------------------------------------"
                                write-host -foreground Cyan "Adding Storage Pool $PoolName to StorageSystem $($ThisStorageSystem.Name) "
                                write-host -foreground Cyan "-------------------------------------------------------------"
                                $task = Add-HPOVStoragePool -StorageSystem $ThisStorageSystem -poolName $PoolName | Wait-HPOVTaskComplete
                            }
                            else
                            {
                                write-host -ForegroundColor Yellow " Storage Pool Name $PoolName does not exist or already in Managed pools" 
                            }


                        }

                    }
                    else
                    {
                       write-host -ForegroundColor Yellow " Storage Pool Name is empty. Skip adding storage pool.... "
                    }





                }

            }
            else
            {
                write-host -foreground Yellow "Storage Name or username provided is empty. Skip adding storage system." 
            }


        }

}


## -------------------------------------------------------------------------------------------------------------
##
##                     Function Create-OVSANManager
##
## -------------------------------------------------------------------------------------------------------------

Function Create-OVSANManager {
<#
  .SYNOPSIS
    Add SAN MAnagers in OneView
  
  .DESCRIPTION
	Add SAN MAnagers in OneView
        
  .EXAMPLE
    Create-OVSANManager  -OVSANMAnagerCSV c:\Ov-SANManager.CSV 


  .PARAMETER OVSANManagerCSV
    Name of the CSV file containing SAN Manager definition


  .Notes
    NAME:  Create-OVSANManager
    LASTEDIT: 01/13/2016
    KEYWORDS: OV SAN Managers
   
  .Link
     Http://www.hpe.com
 
 #Requires PS -Version 3.0
 #>
Param ([string]$OVSANManagerCSV ="D:\Oneview Scripts\OV-FCNetworks.csv")

    if ( -not (Test-path $OVSANManagerCSV))
    {
        write-host "No file specified or file $OVSANManagerCSV does not exist."
        return
    }


    # Read the CSV Users file
    $tempFile = [IO.Path]::GetTempFileName()
    type $OVSANManagerCSV | where { ($_ -notlike ",,,,*") -and ( $_ -notlike "#*") -and ($_ -notlike ",,,#*") } > $tempfile   # Skip blank line

    
    $ListofSANManagers = import-csv $tempfile

    foreach ($N in $ListofSANManagers)
    {
        $SANName       = $N.SANManagerName
        $Type          = $N.Type
        $Username      = $N.Username
        $Password      = $N.Password
        $Port          = $N.Port
        $UseSSL        = if ($N.UseSSL -ieq "Yes") { "-UseSSL"} else {""}
        
       

        $SanManagerExisted = Get-HPOVSanManager | where Name -like $SANName
        if ($SanManagerExisted -eq $NULL)
        {
            # Add San Manager
            write-host -foreground Cyan "-------------------------------------------------------------"
            write-host -foreground Cyan "Adding SAN MAnager $SANName...."
            write-host -foreground Cyan "-------------------------------------------------------------"

            $Cmds = "Add-HPOVSANManager -hostname $SANName -Type $Type -Username $Username -password $Password -port $port $useSSL"

            Invoke-Expression $Cmds | wait-HPOVTaskComplete

        }
        else
        {
            write-host -ForegroundColor Yellow "SAN Manager $SANName already existed, Skip creating it..."
        }


    }

}



## -------------------------------------------------------------------------------------------------------------
##
##                     Function Create-OVStorageVolumeTemplate
##
## -------------------------------------------------------------------------------------------------------------

Function Create-OVStorageVolumeTemplate {
<#
  .SYNOPSIS
    Create OVStorageVolumeTemplate in OneView
  
  .DESCRIPTION
	Create OVStorageVolumeTemplate in OneView
        
  .EXAMPLE
    Create-OVStorageVolumeTemplate  -OVStorageVolumeTemplateCSV c:\OVStorageVolumeTemplate.CSV 


  .PARAMETER OVStorageVolumeTemplate
    Name of the CSV file containing Storage Volume Template definition


  .Notes
    NAME:  Create-OVStorageVolumeTemplate
    LASTEDIT: 01/13/2016
    KEYWORDS: OV Storage Volume Template
   
  .Link
     Http://www.hpe.com
 
 #Requires PS -Version 3.0
 #>
Param ([string]$OVStorageVolumeTemplateCSV ="D:\Oneview Scripts\OVStorageVolumeTemplate.csv")

    if ( -not (Test-path $OVStorageVolumeTemplateCSV))
    {
        write-host "No file specified or file $OVStorageVolumeTemplateCSV does not exist."
        return
    }


    # Read the CSV Users file
    $tempFile = [IO.Path]::GetTempFileName()
    type $OVStorageVolumeTemplateCSV | where { ($_ -notlike ",,,,*") -and ( $_ -notlike "#*") -and ($_ -notlike ",,,#*") } > $tempfile   # Skip blank line

    
    $ListofStorageVolumeTemplates = import-csv $tempfile

    foreach ($SVT in $ListofStorageVolumeTemplates)
    {
        $TemplateName  = $SVT.TemplateName
        $Description   = $SVT.Description
        $StoragePool   = $SVT.StoragePool
        $StsSystem     = $SVT.StorageSystem
        $Capacity      = $SVT.'Capacity(GB)'
        $ProvTypeParam = if ($SVT.ProvisionningType -ieq 'Thick') { ' -full' } else { ''}
        $SharedParam   = if ($SVT.Shared -ieq 'Yes') { ' -shared' }  else {''}        
       
        
        $StorageSystemParam = ""
        if ($StsSystem)
        {
            $StorageSystem = get-hpovStorageSystem | where{$_.credentials.ip_hostname -eq $StsSystem}
            if ($StorageSystem)
            {
                $StorageSystemParam = "  -StorageSystem `$StorageSystem" 
            }

        }
        if ($StoragePool)
        {
            $ThisPool = $(Get-HPOVStoragePool) -match $StoragePool
            if ($ThisPool -and $TemplateName)   # Name must be defined and Storage Pool must exist
            {
                $ThisTemplate = $(get-HPOVStorageVolumeTemplate) -match  $TemplateName
                if ($ThisTemplate)
                {
                    write-host -ForegroundColor Yellow "Storage Volume Template $TemplateName already existed, Skip creating it..."
                }
                else
                {
                 
                    write-host -foreground Cyan "-------------------------------------------------------------"
                    write-host -foreground Cyan "Creating Storage Volume Template $TemplateName...."
                    write-host -foreground Cyan "-------------------------------------------------------------"

                    $ApplConnectParam = "-applianceConnection `$global:ApplianceConnection "
                    $SVTCmds = "New-HPOVStorageVolumeTemplate -templateName `$TemplateName -description `$Description -storagePool `$StoragePool -capacity $Capacity $ApplConnectParam  $StorageSystemParam $SharedParam $provTypeParam " 
                
                    $ThisSVT = Invoke-Expression $SVTCmds 
                    
                }

             }
             else
             {
                write-host -ForegroundColor Yellow "Template Name is empty or Storage Pool not specified nor existed..."
             }

        } #end Storagepool Not NULL
        else
        {
            write-host -ForegroundColor Yellow "Storage Pool not specified. Skip creating StoragePool"
        }
    

    }
}


## -------------------------------------------------------------------------------------------------------------
##
##                     Function Create-OVStorageVolume
##
## -------------------------------------------------------------------------------------------------------------

Function Create-OVStorageVolume {
<#
  .SYNOPSIS
    Create OVStorageVolume in OneView
  
  .DESCRIPTION
	Create OVStorageVolume in OneView
        
  .EXAMPLE
    Create-OVStorageVolume  -OVStorageVolumeCSV c:\OVStorageVolume.CSV 


  .PARAMETER OVStorageVolume
    Name of the CSV file containing Storage Volume  definition


  .Notes
    NAME:  Create-OVStorageVolume
    LASTEDIT: 01/13/2016
    KEYWORDS: OV Storage Volume 
   
  .Link
     Http://www.hpe.com
 
 #Requires PS -Version 3.0
 #>
Param ([string]$OVStorageVolumeCSV,
       [string]$OVStorageVolumeTemplateCSV)

    if ( -not (Test-path $OVStorageVolumeCSV))
    {
        write-host "No file specified or file $OVStorageVolumeCSV does not exist."
        return
    }

    # Create Volume Templates if needed
    write-host -foreground Cyan "-------------------------------------------------------------"
    write-host -foreground Cyan "A - Creating Storage Volume Templates ......"
    write-host -foreground Cyan "-------------------------------------------------------------"
    Create-OVStorageVolumeTemplate -OVStorageVolumeTemplateCSV $OVStorageVolumeTemplateCSV


    write-host -foreground Cyan "-------------------------------------------------------------"
    write-host -foreground Cyan "B - Creating Storage Volumes ......"
    write-host -foreground Cyan "-------------------------------------------------------------"

    # Read the CSV Users file
    $tempFile = [IO.Path]::GetTempFileName()
    type $OVStorageVolumeCSV | where { ($_ -notlike ",,,,*") -and ( $_ -notlike "#*") -and ($_ -notlike ",,,#*") } > $tempfile   # Skip blank line

    
    $ListofStorageVolumes = import-csv $tempfile

    foreach ($SV in $ListofStorageVolumes)
    {
        $VolName       = $SV.VolumeName 
        $Description   = $SV.Description
        $StoragePool   = $SV.StoragePool
        $StsSystem     = $SV.StorageSystem
        
        $VolTemplate   = $SV.VolumeTemplate

        $Capacity      = $SV.'Capacity(GB)'
        $ProvTypeParam = if ($SV.ProvisionningType -ieq 'Thick') { ' -full' } else { ''}
        $SharedParam   = if ($SV.Shared -ieq 'Yes') { ' -shared' }  else {''}        
       
        
        if ($VolTemplate)
        {
            $ProvTypeParam    = ""
            $DescParam        = ""
            $stsSystemParam   = ""
            $StsPoolParam     = ""
            $VolTemplateParam = " -VolumeTemplate $VolTemplate " 
        }
        else
        {
            $VolTemplateParam = ""

            # Configure Desc param
            $DescParam = " -description `'$Description`'" 
            


            # Configure StorageSystem Param

            $StsSystemParam = ""
            if ($StsSystem)
            {
                $StorageSystem = get-hpovStorageSystem | where{$_.credentials.ip_hostname -eq $StsSystem}
                if ($StorageSystem)
                {
    ## This is a workaround for the inconsistent type of Stroage Betwenn the Tempalte and the volume
    ##    object vs string
                    $StorageSystemName = $StorageSystem.Name
                    $StsSystemParam = "  -StorageSystem `$StorageSystemName " 
                }

            }
            
            # Configure StoragePool Param
            $StsPoolParam = $ThisPool = ""
              
            if ($StoragePool)
            { 
                $ListofPools = Get-HPOVStoragePool
                $ThisPool = $ListofPools  -match $StoragePool 
                 
                if ( $ThisPool )
                {
                    $stsPoolParam = " -StoragePool `$StoragePool " 
                }

            }
            
        }
            
        # either VolName must not be Null or Template not null or StoragePool not null
        if (!$VolName) 
        {
            write-host -ForegroundColor Yellow "Volume Name is empty or Storage Pool not specified nor existed..."
        }
        else # VolName specified
        {
            $SVCmds  = ""
             
            $ListofVols = Get-HPOVStorageVolume 
            $ThisVolume = $ListofVols  -match $VolName
            if ( $ThisVolume)
            {
                write-host -ForegroundColor Yellow "Volume $VolName already exists. Skip creating volumes...."
            }
            else
            {
                # Put VolName between quotes as it may have spaces
                $VolName = "`'$VolName`'" 

                if (!$VolTemplate)
                {
                    if (!$stsPoolParam)
                    {
                        write-host -ForegroundColor Yellow "Volume Template not specified and StoragePool not specified/not existed. Not enough information to create volumes. Skip it....."
                        
                    }
                    else # Use StoragePool 
                    {
                        $SVCmds = "New-HPOVStorageVolume -volumeName $VolName -applianceConnection `$global:ApplianceConnection  $descparam  $SharedParam  $stsPoolparam $stsSystemParam $ProvTypeparam -capacity $Capacity" 
 
                    }

                }
                else # Volume Template not NULL
                {
                    $ThisVolTemplate = Get-HPOVStorageVolumeTemplate -templateName $VolTemplate
                    if ( $ThisVolTemplate) # Volume Template exists 
                    {
                        $SVCmds = "New-HPOVStorageVolume -volumeName $VolName $VolTemplateParam -capacity $Capacity $SharedParam -applianceConnection `$global:ApplianceConnection  "               
                    }
                    else
                    {
                        write-host -ForegroundColor Yellow "Volume Template does not exist. Please create it first"
                    }

                                   
                } #end else Volume Template not NULL


                if ( $SVCmds)
                { 
                    write-host -foreground Cyan "-------------------------------------------------------------"
                    write-host -foreground Cyan "Creating Storage Volume $VolName...."
                    write-host -foreground Cyan "-------------------------------------------------------------"

                    Invoke-Expression $SVCmds | Wait-HPOVTaskComplete
                }

            } # end else Volume exists



        } # End VolName empty

    

    }
}



## -------------------------------------------------------------------------------------------------------------
##
##                     Function Create-OVProfileStorage
##
## -------------------------------------------------------------------------------------------------------------

Function Create-OVProfileStorage {
<#
  .SYNOPSIS
    Create ProfileStorage in OneView
  
  .DESCRIPTION
	Create ProfileStorage in OneView and return a hash table of Server ProfileName and connection list
        
  .EXAMPLE
    .\Create-OVProfileStorage  -OVProfileStorageCSV c:\OV-ProfileStorage.CSV -OVProfileName ThisProfile
    

  .PARAMETER OVProfileStorageCSV
    Name of the CSV file containing Server Profile Connection definition
	


  .Notes
    NAME:  Create-OVProfileStorage
    LASTEDIT: 01/20/2016
    KEYWORDS: OV Profile Storage
   
  .Link
     Http://www.hpe.com
 
 #Requires PS -Version 3.0
 #>

 Param ( [string]$OVProfileStorageCSV ="", [string]$OVProfileName="")

         if ( -not (Test-path $OVProfileStorageCSV))
        {
            write-host "No file specified or file $OVProfileStorageCSV does not exist."
            return
        }


        # Read the CSV  file
        $tempFile = [IO.Path]::GetTempFileName()
        type $OVProfileStorageCSV | where { ($_ -notlike ",,,,*") -and ( $_ -notlike "#*") -and ($_ -notlike ",,,#*") } > $tempfile   # Skip blank line

        $script:StorageVolList = @()     # List of Storage Volumes to be associated with a given server profile


        ## Update StorageSystem first
       
        $StorageSystemList = Get-HPOVStorageSystem
        if ($StorageSystemList)
        {
            $StorageSystemList | Update-HPOVStorageSystem
        }

       
        if ($OVProfileName)
        {
            $ListofVols = import-csv $tempfile
        }
        else
        {
            $ListofVols = $NULL
        }

        $ProfileStorageParam = ""

        foreach ($VolEntry in $($ListofVols | where ServerProfileName -match $OVProfileName))
        {
            $SANStorage          = $VolEntry.EnableSANStorage
            $LocalStorage        = $VolEntry.LocalStorage
            $EnableLocalStorage  = if ($LocalStorage -ieq "Yes") { $true} else {$False}

            #
            #  Define LocalStorage settings once when SANStorage row is set to '#"
            #  
            if ($SANStorage -ieq "#")
            {
                    
                
                $InitStsParam    = if ($VolEntry.InitializeStorageController -ieq "Yes") { " -Initialize "} else {""}
                $DrvBootParam    = if ($VolEntry.DriveBootable -ieq "Yes") { " -Bootable "} else {""}
                        $raid    =   $VolEntry.RAIDtype 
                $RaidParam       = if ( $raid ) { " -RaidLevel $raid " } else { ""}  
                #$RaidParam       = if ( $raid -and (($raid -eq "RAID0") -or ($raid -eq "RAID1"))) { " -RaidLevel $raid " } else { " -RaidLevel None "} 
                
                if ( $EnableLocalStorage)
                {
                    $LocalStsParam = " -LocalStorage "
                    ## As of v2.0 appliance, Only integrated controller is managed
                    $ManagedIntegratedController = $true

                    if ( $ManagedIntegratedController)
                    {
                        $RaidParam       = if ( $raid ) { " -RaidLevel $raid " } else { " - RaidLevel NONE "}
                        $LocalStsParam += $RaidParam + $DrvBootParam + $InitStsParam + $RaidParam
                    }

                    #Profile Settings for Local storage
                    # AS OF V2.0 APPLIANCE
                    $ProfileStorageParam = $LocalstsParam
                    

                }

 
       
            }
            Else # San Storage Settings here
            {
                  
                $VolName            = $VolEntry.VolumeName
                $LunID              = $VolEntry.LunID
                $VolID              = $VolEntry.VolumeID
                $stsOSType          = $VolEntry.HostOSType

                $stsSANParam        = if ($SANStorage -ieq 'Yes') { " -SANStorage:`$true " } else { " -SANStorage:`$false" }
                     

                     
                ### Work on Volume param

                $ThisVolume = $(Get-HPOVStorageVolume) -match $VolName
              
                if ($ThisVolume)
                {
                
                    $script:StorageVolList += $ThisVolume | New-HPOVProfileAttachVolume -VolumeID $VolID 
                        
                    ### Work on Host OS Type 
                    $stsOSParam = ""
                    if ($stsOSType)
                    {
                        $stsOSParam = " -HostOSType $stsOSType " 
                    }

                }
                Else
                {
                    write-host -ForegroundColor Yellow " Volume $VolName not existed, skip attaching it to list of Volumes...." 

                }
                
                
            } # End else SAN storage


        } # end foreach

        if ($script:StorageVolList)
        {

            $ProfileStorageParam += " -Storagevolume `$script:StorageVolList $stsOSParam $stsSANParam "
        }

        
        return $ProfileStorageParam
}


# -------------------------------------------------------------------------------------------------------------
#
#                  Main Entry
#
#
# -------------------------------------------------------------------------------------------------------------


       # -----------------------------------
       #    Always reload module
   
       $LoadedModule = get-module -listavailable $OneviewModule


       if ($LoadedModule -ne $NULL)
       {
            $LoadedModule = $LoadedModule.Name.Split('.')[0] + "*"
            remove-module $LoadedModule
       }

       import-module $OneViewModule
       

        # ---------------- Connect to OneView appliance
        #
        write-host "`n Connect to the OneView appliance..."
        $global:ApplianceConnection = Connect-HPOVMgmt -appliance $OVApplianceIP -user $OVAdminName -password $OVAdminPassword

    if ( ! [string]::IsNullOrEmpty($OVEthernetNetworksCSV) -and (Test-path $OVEthernetNetworksCSV) )
        {
            Create-OVEthernetNetworks -OVEthernetNetworksCSV $OVEthernetNetworksCSV 
        }



    if ( ! [string]::IsNullOrEmpty($OVLogicalInterConnectGroupCSV) -and (Test-path $OVLogicalInterConnectGroupCSV) )
        {
            Create-OVLogicalInterConnectGroup -OVLogicalInterConnectGroupCSV $OVLogicalInterConnectGroupCSV 
        }

    if ( ! [string]::IsNullOrEmpty($OVUpLinkSetCSV) -and (Test-path $OVUpLinkSetCSV) )
        {
            Create-OVUplinkSet -OVUpLinkSetCSV $OVUplinkSetCSV 
        }

    
    if ( ! [string]::IsNullOrEmpty($OVEnclosureGroupCSV) -and (Test-path $OVEnclosureGroupCSV) )
        {
            Create-OVEnclosureGroup -OVEnclosureGroupCSV $OVEnclosureGroupCSV 
        }

   if ( ! [string]::IsNullOrEmpty($OVEnclosureCSV) -and (Test-path $OVEnclosureCSV) )
        {
           Create-OVEnclosure -OVEnclosureCSV $OVEnclosureCSV 
 
        }

        
    if ( ! [string]::IsNullOrEmpty($OVProfileCSV) -and (Test-path $OVProfileCSV) )
        {
            Create-OVProfile -OVProfileCSV $OVProfileCSV -OVProfileConnectionCSV $OVProfileConnectionCSV -OVProfileStorageCSV $OVProfileStorageCSV 
        }


    if ( ($BayStart -ne $NULL) -and ($BayEnd -ne $Null) -and ($OVProfileTemplate) -and ($OVEnclosure) )
        {
            Copy-OVProfile -BayStart $BayStart -BayEnd $BayEnd -OVProfileTemplate $OVProfileTemplate -OVEnclosure $OVEnclosure
        }


    if ( ! [string]::IsNullOrEmpty($OVStorageSystemCSV) -and (Test-path $OVStorageSystemCSV) )
        {
            Create-OVStorageSystem -OVStorageSystemCSV $OVStorageSystemCSV -OVFCNetworksCSV $OVFCNetworksCSV
            $OVFCNetworksCSV = ""
        }

    if ( ! [string]::IsNullOrEmpty($OVFCNetworksCSV) -and (Test-path $OVFCNetworksCSV) )
        {
            Create-OVFCNetworks -OVFCNetworksCSV $OVFCNetworksCSV 
        }  
             
         
    if ( ! [string]::IsNullOrEmpty($OVSanManagerCSV) -and (Test-path $OVSanManagerCSV) )
        {
        Create-OVSanManager -OVSanManagerCSV $OVSanManagerCSV 
        }

    if ( ! [string]::IsNullOrEmpty($OVStorageVolumeCSV) -and (Test-path $OVStorageVolumeCSV) )
        {
        Create-OVStorageVolume -OVStorageVolumeCSV $OVStorageVolumeCSV -OVStorageVolumeTemplateCSV $OVStorageVolumeTemplateCSV 
        }

    
    



$s= @"
 
      

    if ( ! [string]::IsNullOrEmpty($OVProfileConnectionCSV) -and (Test-path $OVProfileConnectionCSV) )
        {
         Create-OVProfileConnection -OVProfileConnectionCSV $OVProfileConnectionCSV 
        }

    if ( ! [string]::IsNullOrEmpty($OVProfileStorageCSV) -and (Test-path $OVProfileStorageCSV) )
        {
        
        $stsProfileCmds =Create-OVProfileStorage -OVProfileStorageCSV $OVProfileStorageCSV -OVProfileName "Prod ESXi Server Bay 01"
        $stsProfileCmds
        }
"@
    
    # Clean up
    write-host -foreground Cyan "-----------------------------------------"
    write-host -foreground Cyan " Disconnect the OneView appliance........"
    write-host -foreground Cyan "-----------------------------------------"
    Disconnect-HPOVMgmt