﻿Connect-HPOVMgmt -appliance  192.168.1.21 -user Administrator -password password
    #$Task = Get-HPOVProfile | Remove-HPOVProfile -force -Confirm:$false
    #If($Task){$Task | %{$Wait = Wait-HPOVTaskComplete -taskUri $_.uri -timeout (New-TimeSpan -Minutes 60)}}
    Get-HPOVProfile | Remove-HPOVProfile -force -Confirm:$false | Wait-HPOVTaskComplete
    
    write-host -ForegroundColor Green "Removing Volumes"
    #$Task = Get-HPOVStorageVolume | Remove-HPOVStorageVolume -Confirm:$false
    Get-HPOVStorageVolume | Remove-HPOVStorageVolume -Confirm:$false | Wait-HPOVTaskComplete 
    
    write-host -ForegroundColor Green "Removing Volume Templates"
    Get-HPOVStorageVolumeTemplate | Remove-HPOVStorageVolumeTemplate -Confirm:$false | Wait-HPOVTaskComplete 
    #$Task = Get-HPOVStorageVolumeTemplate | Remove-HPOVStorageVolumeTemplate -Confirm:$false
    #If($Task){$Task | %{$Wait = Wait-HPOVTaskComplete -taskUri $_.uri -timeout (New-TimeSpan -Minutes 60)}}
    
    write-host -ForegroundColor Green "Removing Storage Systems"
    
    #$Task = Get-HPOVStorageSystem | Remove-HPOVStorageSystem -force -Confirm:$false
    #If($Task){$Task | %{$Wait = Wait-HPOVTaskComplete -taskUri $_.uri -timeout (New-TimeSpan -Minutes 60)}}
    Get-HPOVStorageSystem | Remove-HPOVStorageSystem -force -Confirm:$false| Wait-HPOVTaskComplete 
    
        write-host -ForegroundColor Green "Removing SAN Manager"
    
    Get-HPOVSANManager | Remove-HPOVSANMAnager  -Confirm:$false| Wait-HPOVTaskComplete 
    
    write-host -ForegroundColor Green "Removing Enclosures"
    #$Task = Get-HPOVEnclosure | Remove-HPOVEnclosure -force -Confirm:$false 
    #If($Task){$Wait = Wait-HPOVTaskComplete -taskUri $Task.uri -timeout (New-TimeSpan -Minutes 60)}
    Get-HPOVEnclosure | Remove-HPOVEnclosure -force -Confirm:$false | Wait-HPOVTaskComplete
     
    write-host -ForegroundColor Green "Removing Enclosure Groups"
    #$Task = Get-HPOVEnclosureGroup | Remove-HPOVEnclosureGroup -force -Confirm:$false 
    Get-HPOVEnclosureGroup | Remove-HPOVEnclosureGroup -force -Confirm:$false | Wait-HPOVTaskComplete
    
    write-host -ForegroundColor Green "Removing Networks"
    #$Task = Get-HPOVNetwork | Remove-HPOVNetwork -Confirm:$false 
    Get-HPOVNetwork | Remove-HPOVNetwork -Confirm:$false | Wait-HPOVTaskComplete
    
    write-host -ForegroundColor Green "Removing Network Sets"
    #$Task = Get-HPOVNetworkSet | Remove-HPOVNetworkSet -Confirm:$false
    #If($Task){$Task | %{$Wait = Wait-HPOVTaskComplete -taskUri $_.uri -timeout (New-TimeSpan -Minutes 60)}}
    Get-HPOVNetworkSet | Remove-HPOVNetworkSet -Confirm:$false | Wait-HPOVTaskComplete
    
    write-host -ForegroundColor Green "Removing Logical Interconnect Groups"
    #$Task = Get-HPOVLogicalInterconnectGroup | Remove-HPOVLogicalInterconnectGroup -force -Confirm:$false
    #If($Task){$Task | %{$Wait = Wait-HPOVTaskComplete -taskUri $_.uri -timeout (New-TimeSpan -Minutes 60)}}
    Get-HPOVLogicalInterconnectGroup | Remove-HPOVLogicalInterconnectGroup  -Confirm:$false | Wait-HPOVTaskComplete
Disconnect-HPOVMgmt
