﻿## Creating Ethernet networks
C:\OneView\Creator.ps1 -OVEthernetNetworksCSV C:\OneView\csv\1-EthernetNetworks.csv -OVApplianceIP 192.168.1.21 -OVAdminName administrator -OVAdminPassword password -OneViewModule HPOneView.200


## Creating SAN Manager
C:\OneView\Creator.ps1 -OVSanManagerCSV C:\OneView\csv\2a-SANManager.csv -OVApplianceIP 192.168.1.21 -OVAdminName administrator -OVAdminPassword password -OneViewModule HPOneView.200


## Creating StorageSystem and FC networks
C:\OneView\Creator.ps1 -OVStorageSystemCSV C:\OneView\csv\3a-StorageSystem.csv -OVFCNetworksCSV C:\OneView\csv\3b-FCNetworks.csv -OVApplianceIP 192.168.1.21 -OVAdminName administrator -OVAdminPassword password -OneViewModule HPOneView.200

## Creating Storage Volumes
C:\OneView\Creator.ps1 -OVStorageVolumeTemplateCSV C:\OneView\csv\4a-StorageVolumeTemplate.csv  -OVStorageVolumeCSV C:\OneView\csv\4b-StorageVolume.csv -OVApplianceIP 192.168.1.21 -OVAdminName administrator -OVAdminPassword password -OneViewModule HPOneView.200

## Creating Logical Interconnect Group
C:\OneView\Creator.ps1  -OVLogicalInterConnectGroupCSV C:\OneView\csv\5-LogicalInterConnectGroup.csv -OVApplianceIP 192.168.1.21 -OVAdminName administrator -OVAdminPassword password -OneViewModule HPOneView.200

## Creating Uplink Sets
C:\OneView\Creator.ps1  -OVUplinkSetCSV C:\OneView\csv\6-Uplinkset.csv -OVApplianceIP 192.168.1.21 -OVAdminName administrator -OVAdminPassword password -OneViewModule HPOneView.200

## Creating Enclosure Groups
C:\OneView\Creator.ps1  -OVEnclosureGroupCSV C:\OneView\csv\7-EnclosureGroup.csv -OVApplianceIP 192.168.1.21 -OVAdminName administrator -OVAdminPassword password -OneViewModule HPOneView.200


## Creating Enclosures
C:\OneView\Creator.ps1  -OVEnclosureCSV C:\OneView\csv\8-Enclosure.csv -OVApplianceIP 192.168.1.21 -OVAdminName administrator -OVAdminPassword password -OneViewModule HPOneView.200



## Creating Server Profiles
C:\OneView\Creator.ps1  -OVProfileCSV C:\OneView\csv\9a-Profile.csv -OVProfileConnectionCSV C:\OneView\csv\9b-ProfileConnection.csv -OVProfileStorageCSV C:\OneView\csv\9c-ProfileStorage.csv -OVApplianceIP 192.168.1.21 -OVAdminName administrator -OVAdminPassword password -OneViewModule HPOneView.200
