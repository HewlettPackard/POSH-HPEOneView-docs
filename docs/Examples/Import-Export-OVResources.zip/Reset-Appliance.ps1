﻿Param (
    [string]$appliance="172.16.1.54",
    [string]$user="Administrator",
    [string]$password="Password1"
)

if ((test-path variable:connectedSessions) -and ($connectedSessions)) {
    write-host -ForegroundColor Yellow "DISConnecting existing Oneview Sessions"
    while ($ConnectedSessions.count -gt 0) {Disconnect-HPOVMgmt -host $ConnectedSessions[$($ConnectedSessions.count-1)].Name; }
    Start-Sleep -Seconds 3 #Lets operation complete
    }

    write-host -ForegroundColor Yellow "Connecting to Oneview"
    Connect-HPOVMgmt -appliance $appliance -user $user -password $password
$ErrorActionPreference = "stop"

    write-host -ForegroundColor Green "Removing Profiles"
    Get-HPOVServer | Stop-HPOVServer -force -confirm:$False | wait-hpovTaskComplete
    Get-HPOVServerProfile | Remove-HPOVServerProfile -force -Confirm:$false | Wait-HPOVTaskComplete

    Get-HPOVServerProfileTemplate | Remove-HPOVServerProfileTemplate -force -Confirm:$false | Wait-HPOVTaskComplete


    write-host -ForegroundColor Green "Removing Volumes"
    Get-HPOVStorageVolume | Remove-HPOVStorageVolume -Confirm:$false | Wait-HPOVTaskComplete

    write-host -ForegroundColor Green "Removing Volume Templates"
    $objTask = Get-HPOVStorageVolumeTemplate | Remove-HPOVStorageVolumeTemplate -Confirm:$false
    if ($objTask) {Wait-HPOVTaskComplete -InputObject $objTask}


    write-host -ForegroundColor Green "Removing Storage Systems"
    Get-HPOVStorageSystem | Remove-HPOVStorageSystem -force -Confirm:$false| Wait-HPOVTaskComplete

    write-host -ForegroundColor Green "Removing Fibre Channel Networks"
    Get-HPOVNetwork -Type FC | Remove-HPOVNetwork -Confirm:$false | Wait-HPOVTaskComplete
    Get-HPOVNetwork -Type FCOE | Remove-HPOVNetwork -Confirm:$false | Wait-HPOVTaskComplete



    write-host -ForegroundColor Green "Removing Logical Enclosure"
    Get-HPOVLogicalEnclosure | Remove-HPOVLogicalEnclosure -Confirm:$false | Wait-HPOVTaskComplete

    write-host -ForegroundColor Green "Removing Enclosures"
    Get-HPOVEnclosure | Remove-HPOVEnclosure -force -Confirm:$false | Wait-HPOVTaskComplete

    write-host -ForegroundColor Green "Removing Enclosure Groups"
    #Remove-HPOVEnclosureGroup does not return a task object
    Get-HPOVEnclosureGroup | Remove-HPOVEnclosureGroup -force -Confirm:$false

    write-host -ForegroundColor Green "Removing Logical Interconnect Groups"
    Get-HPOVLogicalInterconnectGroup | Remove-HPOVLogicalInterconnectGroup  -Confirm:$false | Wait-HPOVTaskComplete

    write-host -ForegroundColor Green "Removing Networks"
    Get-HPOVNetwork | Remove-HPOVNetwork -Confirm:$false | Wait-HPOVTaskComplete

    write-host -ForegroundColor Green "Removing Network Sets"
    Get-HPOVNetworkSet | Remove-HPOVNetworkSet -Confirm:$false | Wait-HPOVTaskComplete

    write-host -ForegroundColor Green "Removing SAN Manager"
    Get-HPOVSANManager | Remove-HPOVSANMAnager  -Confirm:$false| Wait-HPOVTaskComplete

    write-host -ForegroundColor Green "Address Pools"
    #Task object not returned by Remove-HPOVAddressPoolSubnet & Remove-HPOVAddressPoolRange
    Get-HPOVAddressPoolSubnet | Remove-HPOVAddressPoolSubnet -Confirm:$false
    Get-HPOVAddressPoolRange | Remove-HPOVAddressPoolRange -Confirm:$false

    write-host -ForegroundColor Green "Users"
    Get-HPOVUser | ?{!( ($_.username -eq "administrator") -or ($_.username -eq "HardwareSetup") )} | Remove-HPOVUser -Confirm:$false

Disconnect-HPOVMgmt
