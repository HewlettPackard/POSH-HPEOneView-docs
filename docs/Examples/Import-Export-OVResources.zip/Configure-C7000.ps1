
write-host -foreground Cyan "----------------------------------------------------------"
write-host -foreground Cyan " Configure Address Pool"
write-host -foreground Cyan " .\Import-OVResources.ps1 -OVApplianceIP 10.254.13.212 -OVAddressPoolCSV .\c7000\AddressPool.csv"
write-host -foreground Cyan "----------------------------------------------------------"
$a = read-host -Prompt " Hit <Enter> when ready......."
.\Import-OVResources.ps1 -OVApplianceIP 10.254.13.212 -OVAddressPoolCSV .\c7000\AddressPool.csv

write-host -foreground Cyan "----------------------------------------------------------"
write-host -foreground Cyan " Configure Ethernet networks"
write-host -foreground Cyan " .\Import-OVResources.ps1 -OVApplianceIP 10.254.13.212 -OVEthernetNetworksCSV .\c7000\EthernetNetworks.csv"
write-host -foreground Cyan "----------------------------------------------------------"
$a = read-host -Prompt " Hit <Enter> when ready......."
.\Import-OVResources.ps1 -OVApplianceIP 10.254.13.212 -OVEthernetNetworksCSV .\c7000\EthernetNetworks.csv

write-host -foreground Cyan "----------------------------------------------------------"
write-host -foreground Cyan " Configure Storage - SAN Manager"
write-host -foreground Cyan " .\Import-OVResources.ps1 -OVApplianceIP 10.254.13.212 -OVSanManagerCSV .\c7000\SANManager.csv"
write-host -foreground Cyan "----------------------------------------------------------"
$a = read-host -Prompt " Hit <Enter> when ready......."
.\Import-OVResources.ps1 -OVApplianceIP 10.254.13.212 -OVSanManagerCSV .\c7000\SANManager.csv

write-host -foreground Cyan "----------------------------------------------------------"
write-host -foreground Cyan " Configure Storage - Storage Systems and FC networks"
write-host -foreground Cyan " .\Import-OVResources.ps1 -OVApplianceIP 10.254.13.212 -OVStorageSystemCSV .\c7000\StorageSystems.csv -OVFCNetworksCSV .\c7000\FCNetworks.csv"
write-host -foreground Cyan "----------------------------------------------------------"
$a = read-host -Prompt " Hit <Enter> when ready......."
.\Import-OVResources.ps1 -OVApplianceIP 10.254.13.212 -OVStorageSystemCSV .\c7000\StorageSystems.csv -OVFCNetworksCSV .\c7000\FCNetworks.csv

write-host -foreground Cyan "----------------------------------------------------------"
write-host -foreground Cyan " Configure Storage - Volume Templates"
write-host -foreground Cyan " .\Import-OVResources.ps1 -OVApplianceIP 10.254.13.212 -OVStorageVolumeTemplateCSV .\c7000\StorageVolumeTemplate.csv"
write-host -foreground Cyan "----------------------------------------------------------"
$a = read-host -Prompt " Hit <Enter> when ready......."
.\Import-OVResources.ps1 -OVApplianceIP 10.254.13.212 -OVStorageVolumeTemplateCSV .\c7000\StorageVolumeTemplate.csv

write-host -foreground Cyan "----------------------------------------------------------"
write-host -foreground Cyan " Configure Storage - Volumes"
write-host -foreground Cyan " .\Import-OVResources.ps1 -OVApplianceIP 10.254.13.212 -OVStorageVolumeCSV .\c7000\StorageVolume.csv"
write-host -foreground Cyan "----------------------------------------------------------"
$a = read-host -Prompt " Hit <Enter> when ready......."
.\Import-OVResources.ps1 -OVApplianceIP 10.254.13.212 -OVStorageVolumeCSV .\c7000\StorageVolume.csv

write-host -foreground Cyan "----------------------------------------------------------"
write-host -foreground Cyan " Configure Logical InterConnect Groups"
write-host -foreground Cyan " .\Import-OVResources.ps1 -OVApplianceIP 10.254.13.212 -OVLogicalInterConnectGroupCSV .\c7000\LogicalInterconnectGroup.csv"
write-host -foreground Cyan "----------------------------------------------------------"
$a = read-host -Prompt " Hit <Enter> when ready......."
.\Import-OVResources.ps1 -OVApplianceIP 10.254.13.212 -OVLogicalInterConnectGroupCSV .\c7000\LogicalInterconnectGroup.csv

write-host -foreground Cyan "----------------------------------------------------------"
write-host -foreground Cyan " Configure Uplink Sets"
write-host -foreground Cyan " .\Import-OVResources.ps1 -OVApplianceIP 10.254.13.212 -OVUpLinkSetCSV .\c7000\uplinkset.csv"
write-host -foreground Cyan "----------------------------------------------------------"
$a = read-host -Prompt " Hit <Enter> when ready......."
.\Import-OVResources.ps1 -OVApplianceIP 10.254.13.212 -OVUpLinkSetCSV .\c7000\UpLinkSet.csv

write-host -foreground Cyan "----------------------------------------------------------"
write-host -foreground Cyan " Configure Enclosure Group"
write-host -foreground Cyan " .\Import-OVResources.ps1 -OVApplianceIP 10.254.13.212 -OVEnclosuregroupCSV .\c7000\Enclosuregroup.csv"
write-host -foreground Cyan "----------------------------------------------------------"
$a = read-host -Prompt " Hit <Enter> when ready......."
.\Import-OVResources.ps1 -OVApplianceIP 10.254.13.212 -OVEnclosureGroupCSV .\c7000\EnclosureGroup.csv

write-host -foreground Cyan "----------------------------------------------------------"
write-host -foreground Cyan " Import Enclosure"
write-host -foreground Cyan " .\Import-OVResources.ps1 -OVApplianceIP 10.254.13.212 -OVEnclosureCSV .\c7000\Enclosure.csv"
write-host -foreground Cyan "----------------------------------------------------------"
$a = read-host -Prompt " Hit <Enter> when ready......."
.\Import-OVResources.ps1 -OVApplianceIP 10.254.13.212 -OVEnclosureCSV .\c7000\Enclosure.csv

write-host -foreground Cyan "----------------------------------------------------------"
write-host -foreground Cyan " Configure Server Profile Templates"
write-host -foreground Cyan " .\Import-OVResources.ps1 -OVApplianceIP 10.254.13.212 -OVProfileTemplateCSV .\c7000\ProfileTemplate.csv -OVProfileLOCALStorageCSV .\c7000\ProfileLOCALStorage.csv -OVProfileSANStorageCSV .\c7000\ProfileSANStorage.csv -OVProfileConnectionCSV .\c7000\ProfileConnection.csv"
write-host -foreground Cyan "----------------------------------------------------------"
$a = read-host -Prompt " Hit <Enter> when ready......."
.\Import-OVResources.ps1 -OVApplianceIP 10.254.13.212 -OVProfileTemplateCSV .\c7000\ProfileTemplate.csv -OVProfileLOCALStorageCSV .\c7000\ProfileLOCALStorage.csv -OVProfileSANStorageCSV .\c7000\ProfileSANStorage.csv -OVProfileConnectionCSV .\c7000\ProfileConnection.csv

write-host -foreground Cyan "----------------------------------------------------------"
write-host -foreground Cyan " Configure Server Profiles"
write-host -foreground Cyan " .\Import-OVResources.ps1 -OVApplianceIP 10.254.13.212 -OVProfileCSV .\c7000\Profile.csv -OVProfileLOCALStorageCSV .\c7000\ProfileLOCALStorage.csv -OVProfileSANStorageCSV .\c7000\ProfileSANStorage.csv -OVProfileConnectionCSV .\c7000\ProfileConnection.csv"
write-host -foreground Cyan "----------------------------------------------------------"
$a = read-host -Prompt " Hit <Enter> when ready......."
.\Import-OVResources.ps1 -OVApplianceIP 10.254.13.212 -OVProfileCSV .\c7000\Profile.csv -OVProfileLOCALStorageCSV .\c7000\ProfileLOCALStorage.csv -OVProfileSANStorageCSV .\c7000\ProfileSANStorage.csv -OVProfileConnectionCSV .\c7000\ProfileConnection.csv