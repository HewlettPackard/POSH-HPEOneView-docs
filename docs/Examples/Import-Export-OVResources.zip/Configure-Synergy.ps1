
write-host -foreground Cyan "----------------------------------------------------------"
write-host -foreground Cyan " Configure Address Pool"
write-host -foreground Cyan " .\Import-OVResources.ps1 -OVApplianceIP 10.254.13.220 -OVAddressPoolCSV .\Synergy\AddressPool.csv"
write-host -foreground Cyan "----------------------------------------------------------"
$a = read-host -Prompt " Hit <Enter> when ready......."
.\Import-OVResources.ps1 -OVApplianceIP 10.254.13.220 -OVAddressPoolCSV .\Synergy\AddressPool.csv

write-host -foreground Cyan "----------------------------------------------------------"
write-host -foreground Cyan " Configure Ethernet networks"
write-host -foreground Cyan " .\Import-OVResources.ps1 -OVApplianceIP 10.254.13.220 -OVEthernetNetworksCSV .\Synergy\EthernetNetworks.csv"
write-host -foreground Cyan "----------------------------------------------------------"
$a = read-host -Prompt " Hit <Enter> when ready......."
.\Import-OVResources.ps1 -OVApplianceIP 10.254.13.220 -OVEthernetNetworksCSV .\Synergy\EthernetNetworks.csv

write-host -foreground Cyan "----------------------------------------------------------"
write-host -foreground Cyan " Configure Storage - SAN Manager"
write-host -foreground Cyan " .\Import-OVResources.ps1 -OVApplianceIP 10.254.13.220 -OVSanManagerCSV .\Synergy\SANManager.csv"
write-host -foreground Cyan "----------------------------------------------------------"
$a = read-host -Prompt " Hit <Enter> when ready......."
.\Import-OVResources.ps1 -OVApplianceIP 10.254.13.220 -OVSanManagerCSV .\Synergy\SANManager.csv

write-host -foreground Cyan "----------------------------------------------------------"
write-host -foreground Cyan " Configure Storage - Storage Systems and FC networks"
write-host -foreground Cyan " .\Import-OVResources.ps1 -OVApplianceIP 10.254.13.220 -OVStorageSystemCSV .\Synergy\StorageSystems.csv -OVFCNetworksCSV .\Synergy\FCNetworks.csv"
write-host -foreground Cyan "----------------------------------------------------------"
$a = read-host -Prompt " Hit <Enter> when ready......."
.\Import-OVResources.ps1 -OVApplianceIP 10.254.13.220 -OVStorageSystemCSV .\Synergy\StorageSystems.csv -OVFCNetworksCSV .\Synergy\FCNetworks.csv

write-host -foreground Cyan "----------------------------------------------------------"
write-host -foreground Cyan " Configure Storage - Volume Templates"
write-host -foreground Cyan " .\Import-OVResources.ps1 -OVApplianceIP 10.254.13.220 -OVStorageVolumeTemplateCSV .\Synergy\StorageVolumeTemplate.csv"
write-host -foreground Cyan "----------------------------------------------------------"
$a = read-host -Prompt " Hit <Enter> when ready......."
.\Import-OVResources.ps1 -OVApplianceIP 10.254.13.220 -OVStorageVolumeTemplateCSV .\Synergy\StorageVolumeTemplate.csv

write-host -foreground Cyan "----------------------------------------------------------"
write-host -foreground Cyan " Configure Storage - Volumes"
write-host -foreground Cyan " .\Import-OVResources.ps1 -OVApplianceIP 10.254.13.220 -OVStorageVolumeCSV .\Synergy\StorageVolume.csv"
write-host -foreground Cyan "----------------------------------------------------------"
$a = read-host -Prompt " Hit <Enter> when ready......."
.\Import-OVResources.ps1 -OVApplianceIP 10.254.13.220 -OVStorageVolumeCSV .\Synergy\StorageVolume.csv

write-host -foreground Cyan "----------------------------------------------------------"
write-host -foreground Cyan " Configure Logical InterConnect Groups"
write-host -foreground Cyan " .\Import-OVResources.ps1 -OVApplianceIP 10.254.13.220 -OVLogicalInterConnectGroupCSV .\Synergy\LogicalInterconnectGroup.csv"
write-host -foreground Cyan "----------------------------------------------------------"
$a = read-host -Prompt " Hit <Enter> when ready......."
.\Import-OVResources.ps1 -OVApplianceIP 10.254.13.220 -OVLogicalInterConnectGroupCSV .\Synergy\LogicalInterconnectGroup.csv

write-host -foreground Cyan "----------------------------------------------------------"
write-host -foreground Cyan " Configure Uplink Sets"
write-host -foreground Cyan " .\Import-OVResources.ps1 -OVApplianceIP 10.254.13.220 -OVUpLinkSetCSV .\Synergy\uplinkset.csv"
write-host -foreground Cyan "----------------------------------------------------------"
$a = read-host -Prompt " Hit <Enter> when ready......."
.\Import-OVResources.ps1 -OVApplianceIP 10.254.13.220 -OVUpLinkSetCSV .\Synergy\UpLinkSet.csv

write-host -foreground Cyan "----------------------------------------------------------"
write-host -foreground Cyan " Configure Enclosure Group"
write-host -foreground Cyan " .\Import-OVResources.ps1 -OVApplianceIP 10.254.13.220 -OVEnclosuregroupCSV .\Synergy\Enclosuregroup.csv"
write-host -foreground Cyan "----------------------------------------------------------"
$a = read-host -Prompt " Hit <Enter> when ready......."
.\Import-OVResources.ps1 -OVApplianceIP 10.254.13.220 -OVEnclosureGroupCSV .\Synergy\EnclosureGroup.csv

write-host -foreground Cyan "----------------------------------------------------------"
write-host -foreground Cyan " Import Enclosure"
write-host -foreground Cyan " .\Import-OVResources.ps1 -OVApplianceIP 10.254.13.220 -OVLogicalEnclosureCSV .\Synergy\LogicalEnclosure.csv"
write-host -foreground Cyan "----------------------------------------------------------"
$a = read-host -Prompt " Hit <Enter> when ready......."
.\Import-OVResources.ps1 -OVApplianceIP 10.254.13.220 -OVLogicalEnclosureCSV .\Synergy\LogicalEnclosure.csv

write-host -foreground Cyan "----------------------------------------------------------"
write-host -foreground Cyan " Configure Server Profile Templates"
write-host -foreground Cyan " .\Import-OVResources.ps1 -OVApplianceIP 10.254.13.220 -OVProfileTemplateCSV .\Synergy\ProfileTemplate.csv -OVProfileLOCALStorageCSV .\Synergy\ProfileLOCALStorage.csv -OVProfileSANStorageCSV .\Synergy\ProfileSANStorage.csv -OVProfileConnectionCSV .\Synergy\ProfileConnection.csv"
write-host -foreground Cyan "----------------------------------------------------------"
$a = read-host -Prompt " Hit <Enter> when ready......."
.\Import-OVResources.ps1 -OVApplianceIP 10.254.13.220 -OVProfileTemplateCSV .\Synergy\ProfileTemplate.csv -OVProfileLOCALStorageCSV .\Synergy\ProfileLOCALStorage.csv -OVProfileSANStorageCSV .\Synergy\ProfileSANStorage.csv -OVProfileConnectionCSV .\Synergy\ProfileConnection.csv

write-host -foreground Cyan "----------------------------------------------------------"
write-host -foreground Cyan " Configure Server Profiles"
write-host -foreground Cyan " .\Import-OVResources.ps1 -OVApplianceIP 10.254.13.220 -OVProfileCSV .\Synergy\Profile.csv -OVProfileLOCALStorageCSV .\Synergy\ProfileLOCALStorage.csv -OVProfileSANStorageCSV .\Synergy\ProfileSANStorage.csv -OVProfileConnectionCSV .\Synergy\ProfileConnection.csv"
write-host -foreground Cyan "----------------------------------------------------------"
$a = read-host -Prompt " Hit <Enter> when ready......."
.\Import-OVResources.ps1 -OVApplianceIP 10.254.13.220 -OVProfileCSV .\Synergy\Profile.csv -OVProfileLOCALStorageCSV .\Synergy\ProfileLOCALStorage.csv -OVProfileSANStorageCSV .\Synergy\ProfileSANStorage.csv -OVProfileConnectionCSV .\Synergy\ProfileConnection.csv