[CmdletBinding()]
param(
    [ValidateNotNull()]
    [ValidateNotNullOrEmpty()]
    [string]$path='C:\Users\PACKJ\OneDrive - Hewlett Packard Enterprise\powershell\HPEOneView\Import-Export\OneViewNetwork-V3-Synergy.xlsx',

    [switch]$Force=$false
)

#Setup Error handling
Set-PSDebug -Strict
Set-StrictMode -Version latest
$ErrorActionPreference = "stop"

#Constants
$xlCSV = 6 #https://msdn.microsoft.com/en-us/library/office/ff198017.aspx

write-verbose "Validating File path"
if (! (test-path -type leaf $path)) {
    #$path is not a file
    Write-Error "$path is not a file"
    exit 1
    }
else {
    #Get folder
    $strFullFileandPathName = (dir $path).fullname
    $strFullFileandPathName
    $strExcelFolder = split-path -parent $strFullFileandPathName
    $strFileName    = $(split-path -leaf $path) -replace $([System.IO.Path]::GetExtension($path)),""
    }

if ([System.IO.Path]::GetExtension($path) -ne ".xlsx") {
    #$path is not an excel file
    Write-Error "$path is not an excel file"
    exit 1
    }

#Create Excel object
write-verbose "Creating Excel Object"
$objExel = New-Object -ComObject Excel.Application
$objExel.Visible = $false
$objExel.DisplayAlerts = $false

write-verbose "Open Excel work book"
try {
    $objExcelWorkBook  = $objExel.Workbooks.Open($strFullFileandPathName)
    }
catch {
    write-error "Failed to open excel workbook $path"
    }

write-verbose "Looping though each work sheet"
foreach ($objWS in $objExcelWorkBook.Worksheets) {

        $strWSName = $objWS.Name
        if ($strWSName -match "^\d") {
            $strWSFileName = $(join-path $strExcelFolder $strFileName)
            $strWSFileName += '_' + $strWSName + ".csv"
            write-verbose "Writting $strWSFileName"
             $objWS.SaveAs($strWSFileName, $xlCSV,"","",$true )

             #Emit file Name
             $strWSFileName
            }
    }
write-verbose "Quiting Excel"
$objExel.Quit()