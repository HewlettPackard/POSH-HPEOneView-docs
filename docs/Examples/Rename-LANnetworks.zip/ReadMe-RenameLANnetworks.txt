Rename-LANnetworks queries HP OneView to collect network names and use those names to rename Local Area Connection network on a Windows server.
It uses the Serial Number as index for the query.


 
